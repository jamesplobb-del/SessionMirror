import AVFoundation
import Capacitor
import CoreVideo
import PDFKit
import Photos
import Speech
import UIKit

@objc(BestTakeAudioPlugin)
public class BestTakeAudioPlugin: CAPPlugin, CAPBridgedPlugin {
    public let identifier = "BestTakeAudioPlugin"
    public let jsName = "BestTakeAudioPlugin"
    public let pluginMethods: [CAPPluginMethod] = [
        CAPPluginMethod(name: "setHighQualityBluetoothMode", returnType: CAPPluginReturnPromise),
        CAPPluginMethod(name: "setDeviceMicForRecording", returnType: CAPPluginReturnPromise),
        CAPPluginMethod(name: "setBluetoothHeadphonePlaybackMode", returnType: CAPPluginReturnPromise),
        CAPPluginMethod(name: "reapplyHeadphonePlaybackRoute", returnType: CAPPluginReturnPromise),
        CAPPluginMethod(name: "enableStereoPlayback", returnType: CAPPluginReturnPromise),
        CAPPluginMethod(name: "enableRecordingRoute", returnType: CAPPluginReturnPromise),
        CAPPluginMethod(name: "getPlaybackOutputProfile", returnType: CAPPluginReturnPromise),
        CAPPluginMethod(name: "startNativePlaybackTest", returnType: CAPPluginReturnPromise),
        CAPPluginMethod(name: "stopNativePlaybackTest", returnType: CAPPluginReturnPromise),
        CAPPluginMethod(name: "startInlineTakeBoxPlayback", returnType: CAPPluginReturnPromise),
        CAPPluginMethod(name: "stopInlineTakeBoxPlayback", returnType: CAPPluginReturnPromise),
        CAPPluginMethod(name: "updateInlineTakeBoxPlaybackLayout", returnType: CAPPluginReturnPromise),
        CAPPluginMethod(name: "setInlineTakeBoxPlaybackVolume", returnType: CAPPluginReturnPromise),
        CAPPluginMethod(name: "prepareCameraLikePlaybackSession", returnType: CAPPluginReturnPromise),
        CAPPluginMethod(name: "setCameraSessionState", returnType: CAPPluginReturnPromise),
        CAPPluginMethod(name: "getCameraSessionState", returnType: CAPPluginReturnPromise),
        CAPPluginMethod(name: "setPlaybackRouteActive", returnType: CAPPluginReturnPromise),
        CAPPluginMethod(name: "restoreRecordingRouteAfterPlayback", returnType: CAPPluginReturnPromise),
        CAPPluginMethod(name: "shareMediaFile", returnType: CAPPluginReturnPromise),
        CAPPluginMethod(name: "saveVideoToPhotos", returnType: CAPPluginReturnPromise),
        CAPPluginMethod(name: "trimTakeMedia", returnType: CAPPluginReturnPromise),
        CAPPluginMethod(name: "renderCreatorStudioVideo", returnType: CAPPluginReturnPromise),
        CAPPluginMethod(name: "renderMultitrackVideo", returnType: CAPPluginReturnPromise),
        CAPPluginMethod(name: "prepareMultitrackMonitor", returnType: CAPPluginReturnPromise),
        CAPPluginMethod(name: "startMultitrackTransport", returnType: CAPPluginReturnPromise),
        CAPPluginMethod(name: "stopMultitrackTransport", returnType: CAPPluginReturnPromise),
        CAPPluginMethod(name: "setNativeExperimentalAudioMode", returnType: CAPPluginReturnPromise),
        CAPPluginMethod(name: "startNativeCameraBridge", returnType: CAPPluginReturnPromise),
        CAPPluginMethod(name: "stopNativeCameraBridge", returnType: CAPPluginReturnPromise),
        CAPPluginMethod(name: "startNativeCameraPreview", returnType: CAPPluginReturnPromise),
        CAPPluginMethod(name: "stopNativeCameraPreview", returnType: CAPPluginReturnPromise),
        CAPPluginMethod(name: "setNativeCameraPassthrough", returnType: CAPPluginReturnPromise),
        CAPPluginMethod(name: "setNativeCameraFrameBridgeEnabled", returnType: CAPPluginReturnPromise),
        CAPPluginMethod(name: "ackNativeCameraPreviewFrame", returnType: CAPPluginReturnPromise),
        CAPPluginMethod(name: "setNativeCameraPreviewZoom", returnType: CAPPluginReturnPromise),
        CAPPluginMethod(name: "setNativeAudioTapEnabled", returnType: CAPPluginReturnPromise),
        CAPPluginMethod(name: "startNativeTunerMonitor", returnType: CAPPluginReturnPromise),
        CAPPluginMethod(name: "stopNativeTunerMonitor", returnType: CAPPluginReturnPromise),
        CAPPluginMethod(name: "ensureNativeCameraSessionHealthy", returnType: CAPPluginReturnPromise),
        CAPPluginMethod(name: "enhanceTakeAudio", returnType: CAPPluginReturnPromise),
        CAPPluginMethod(name: "startNativeCameraRecording", returnType: CAPPluginReturnPromise),
        CAPPluginMethod(name: "stopNativeCameraRecording", returnType: CAPPluginReturnPromise),
        CAPPluginMethod(name: "startNativeAudioRecording", returnType: CAPPluginReturnPromise),
        CAPPluginMethod(name: "stopNativeAudioRecording", returnType: CAPPluginReturnPromise),
        CAPPluginMethod(name: "playNativeCameraTestPostProcess", returnType: CAPPluginReturnPromise),
        CAPPluginMethod(name: "stopNativeCameraTestPostProcess", returnType: CAPPluginReturnPromise),
        CAPPluginMethod(name: "hapticImpact", returnType: CAPPluginReturnPromise),
        CAPPluginMethod(name: "hapticNotification", returnType: CAPPluginReturnPromise),
        CAPPluginMethod(name: "prepareHaptics", returnType: CAPPluginReturnPromise),
        CAPPluginMethod(name: "openAppSettings", returnType: CAPPluginReturnPromise),
        CAPPluginMethod(name: "setTakesBackupExcluded", returnType: CAPPluginReturnPromise),
        CAPPluginMethod(name: "getAudioHardwareRtl", returnType: CAPPluginReturnPromise),
        CAPPluginMethod(name: "getAudioOutputLatencyMs", returnType: CAPPluginReturnPromise),
        CAPPluginMethod(name: "computeTakeAlignment", returnType: CAPPluginReturnPromise),
        CAPPluginMethod(name: "extractWaveformPeaks", returnType: CAPPluginReturnPromise),
        CAPPluginMethod(name: "analyzePracticeTake", returnType: CAPPluginReturnPromise),
        CAPPluginMethod(name: "getSpokenFeedbackPermission", returnType: CAPPluginReturnPromise),
        CAPPluginMethod(name: "startSpokenFeedback", returnType: CAPPluginReturnPromise),
        CAPPluginMethod(name: "stopSpokenFeedback", returnType: CAPPluginReturnPromise),
        CAPPluginMethod(name: "getRuntimeEnvironment", returnType: CAPPluginReturnPromise),
        CAPPluginMethod(name: "createSimulatorTake", returnType: CAPPluginReturnPromise),
    ]

    private let nativeCameraEngine = NativeCameraRecordingEngine.shared
    private var routeObserver: NSObjectProtocol?
    private var nativeTestPlayer: AVPlayer?
    private var nativeTestEndObserver: NSObjectProtocol?
    private var playbackRouteRestorePending = false
    private var jsAudioTapEnabled = false
    private var spokenFeedbackActive = false
    private var spokenFeedbackRequest: SFSpeechAudioBufferRecognitionRequest?
    private var spokenFeedbackTask: SFSpeechRecognitionTask?
    private var spokenFeedbackTranscript = ""
    private let spokenFeedbackQueue = DispatchQueue(label: "com.besttake.spoken-feedback")

    // MARK: - Haptics
    // Pre-instantiated feedback generators kept warm via prepare() so every
    // tap fires crisply and immediately. Dynamically importing a JS haptics
    // module per tap (the old path) let the Taptic Engine idle between taps,
    // which is what made haptics feel weak / dropped ("dwindling").
    private lazy var impactGenerators: [String: UIImpactFeedbackGenerator] = {
        var generators: [String: UIImpactFeedbackGenerator] = [
            "light": UIImpactFeedbackGenerator(style: .light),
            "medium": UIImpactFeedbackGenerator(style: .medium),
            "heavy": UIImpactFeedbackGenerator(style: .heavy),
        ]
        if #available(iOS 13.0, *) {
            generators["soft"] = UIImpactFeedbackGenerator(style: .soft)
            generators["rigid"] = UIImpactFeedbackGenerator(style: .rigid)
        }
        return generators
    }()
    private lazy var notificationGenerator = UINotificationFeedbackGenerator()

    override public func load() {
        super.load()
        nativeCameraEngine.onPreviewFrame = { [weak self] jpegBase64, width, height, frameId in
            self?.notifyListeners("nativeCameraPreviewFrame", data: [
                "jpegBase64": jpegBase64,
                "width": width,
                "height": height,
                "frameId": NSNumber(value: frameId),
            ])
        }
        nativeCameraEngine.onAudioTapChunk = { [weak self] pcmBase64, sampleRate, sampleCount in
            self?.notifyListeners("nativeAudioPitchFrame", data: [
                "pcmBase64": pcmBase64,
                "sampleRate": sampleRate,
                "sampleCount": sampleCount,
            ])
            self?.appendSpokenFeedbackAudio(
                pcmBase64: pcmBase64,
                sampleRate: sampleRate,
                sampleCount: sampleCount
            )
        }
        routeObserver = NotificationCenter.default.addObserver(
            forName: AVAudioSession.routeChangeNotification,
            object: AVAudioSession.sharedInstance(),
            queue: .main
        ) { [weak self] _ in
            AudioRouteConfigurator.logRoute("route-change event")
            guard let self = self else { return }
            self.notifyListeners("audioRouteChanged", data: AudioRouteConfigurator.routeSnapshot())
        }
        DispatchQueue.main.async { [weak self] in
            self?.warmHaptics()
        }
    }

    // MARK: - Haptics

    private func warmHaptics() {
        for generator in impactGenerators.values {
            generator.prepare()
        }
        notificationGenerator.prepare()
    }

    @objc func hapticImpact(_ call: CAPPluginCall) {
        let style = call.getString("style") ?? "medium"
        let requestedIntensity = call.getDouble("intensity")
        DispatchQueue.main.async { [weak self] in
            guard let self = self else {
                call.resolve()
                return
            }
            let generator = self.impactGenerators[style] ?? self.impactGenerators["medium"]
            generator?.prepare()
            if #available(iOS 13.0, *), let requestedIntensity = requestedIntensity {
                let intensity = CGFloat(max(0, min(1, requestedIntensity)))
                generator?.impactOccurred(intensity: intensity)
            } else {
                generator?.impactOccurred()
            }
            // Re-prime immediately so the next tap is just as crisp.
            generator?.prepare()
            call.resolve()
        }
    }

    @objc func hapticNotification(_ call: CAPPluginCall) {
        let typeRaw = call.getString("type") ?? "success"
        let type: UINotificationFeedbackGenerator.FeedbackType
        switch typeRaw {
        case "warning": type = .warning
        case "error": type = .error
        default: type = .success
        }
        DispatchQueue.main.async { [weak self] in
            guard let self = self else {
                call.resolve()
                return
            }
            self.notificationGenerator.notificationOccurred(type)
            self.notificationGenerator.prepare()
            call.resolve()
        }
    }

    @objc func prepareHaptics(_ call: CAPPluginCall) {
        DispatchQueue.main.async { [weak self] in
            self?.warmHaptics()
            call.resolve()
        }
    }

    /**
     * Include or exclude recorded takes from iCloud/iTunes backup.
     *
     * Takes live in Documents, which iOS backs up by default. Video adds up
     * fast, and a heavy user can silently fill a 5GB free iCloud tier — what
     * they see is their phone complaining that backup failed, with no obvious
     * link to this app. Excluding is the opposite trade: nothing to restore if
     * the device is lost, so this is the user's choice, not a default.
     *
     * The flag is set on the directory, which covers files created inside it
     * later, so this does not need re-running per take.
     */
    @objc func setTakesBackupExcluded(_ call: CAPPluginCall) {
        let excluded = call.getBool("excluded") ?? false

        guard let documents = FileManager.default.urls(
            for: .documentDirectory,
            in: .userDomainMask
        ).first else {
            call.reject("Could not locate the Documents directory")
            return
        }

        var takesURL = documents.appendingPathComponent("takes", isDirectory: true)

        if !FileManager.default.fileExists(atPath: takesURL.path) {
            do {
                try FileManager.default.createDirectory(
                    at: takesURL,
                    withIntermediateDirectories: true
                )
            } catch {
                call.reject("Could not create the takes directory: \(error.localizedDescription)")
                return
            }
        }

        do {
            var values = URLResourceValues()
            values.isExcludedFromBackup = excluded
            try takesURL.setResourceValues(values)
            call.resolve(["excluded": excluded])
        } catch {
            call.reject("Could not update the backup flag: \(error.localizedDescription)")
        }
    }

    @objc func openAppSettings(_ call: CAPPluginCall) {
        DispatchQueue.main.async {
            guard let url = URL(string: UIApplication.openSettingsURLString),
                  UIApplication.shared.canOpenURL(url) else {
                call.reject("App Settings are unavailable")
                return
            }
            UIApplication.shared.open(url, options: [:]) { opened in
                if opened {
                    call.resolve()
                } else {
                    call.reject("Could not open App Settings")
                }
            }
        }
    }

    deinit {
        stopNativePlaybackTestPlayer()
        if let routeObserver = routeObserver {
            NotificationCenter.default.removeObserver(routeObserver)
        }
    }

    @objc func setHighQualityBluetoothMode(_ call: CAPPluginCall) {
        let enableHQ = call.getBool("enable") ?? false

        if CameraSessionGuard.shouldBlockRouteChanges() {
            CameraSessionGuard.skipRouteChangeLog()
            call.resolve(AudioRouteConfigurator.routeSnapshot())
            return
        }

        do {
            try AudioRouteConfigurator.applyRecordingRoute(enableHQ: enableHQ)
            var result = AudioRouteConfigurator.routeSnapshot()
            result["success"] = true
            call.resolve(result)
        } catch {
            print("BestTake Audio Error: \(error.localizedDescription)")
            call.reject("Audio routing failed: \(error.localizedDescription)")
        }
    }

    @objc func setDeviceMicForRecording(_ call: CAPPluginCall) {
        let preference = AudioRouteConfigurator.parseMicInputPreference(call.getString("preference"))
        let legacyEnable = call.getBool("enable")
        let resolvedPreference: AudioRouteConfigurator.MicInputPreference = legacyEnable == nil
            ? preference
            : (legacyEnable == true ? .iphone : .auto)

        // No queued/blocked early-return here anymore: setMicInputPreference
        // decides internally — full apply when idle, input-only setPreferredInput
        // when the camera preview / recording / playback route is live. The
        // input-only path never touches setCategory/setActive, so it is safe
        // to run while capture and WebView (YouTube) audio are active.
        do {
            let result = try AudioRouteConfigurator.setMicInputPreference(resolvedPreference)
            call.resolve(result)
        } catch {
            print("BestTake Audio Error: \(error.localizedDescription)")
            call.reject("Mic input preference failed: \(error.localizedDescription)")
        }
    }

    @objc func setBluetoothHeadphonePlaybackMode(_ call: CAPPluginCall) {
        let enable = call.getBool("enable") ?? false
        let applyRoute = call.getBool("applyRoute") ?? false

        do {
            try AudioRouteConfigurator.setHeadphonePlaybackMode(enable, applyRoute: applyRoute)
            var result = AudioRouteConfigurator.routeSnapshot()
            result["success"] = true
            call.resolve(result)
        } catch {
            print("BestTake Audio Error: \(error.localizedDescription)")
            call.reject("Headphone playback mode routing failed: \(error.localizedDescription)")
        }
    }

    @objc func reapplyHeadphonePlaybackRoute(_ call: CAPPluginCall) {
        guard AudioRouteConfigurator.isHeadphonePlaybackModeEnabled() else {
            call.resolve(AudioRouteConfigurator.routeSnapshot())
            return
        }

        do {
            try AudioRouteConfigurator.applyHeadphonePlaybackRoute()
            var result = AudioRouteConfigurator.routeSnapshot()
            result["success"] = true
            call.resolve(result)
        } catch {
            print("BestTake Audio Error: \(error.localizedDescription)")
            call.reject("Headphone playback route reapply failed: \(error.localizedDescription)")
        }
    }

    @objc func enableStereoPlayback(_ call: CAPPluginCall) {
        do {
            let result: [String: Any]
            let session = AVAudioSession.sharedInstance()
            // Camera preview and external output (headphones/BT) both need the
            // coexistent PlayAndRecord path. Forcing Playback on Bluetooth HFP
            // fails (-50) and leaves audio-mode take playback silent.
            if CameraSessionGuard.needsCoexistentPlaybackRoute
                || AudioRouteConfigurator.hasExternalOutput(session) {
                result = try AudioRouteConfigurator.applyCoexistentPlaybackSpeakerRoute()
            } else {
                result = try AudioRouteConfigurator.applyWebPlaybackRoute(webPlaybackActive: true)
            }
            call.resolve(result)
        } catch {
            call.reject("Failed to set stereo playback", nil, error)
        }
    }

    @objc func enableRecordingRoute(_ call: CAPPluginCall) {
        if CameraSessionGuard.shouldBlockRouteChanges() {
            CameraSessionGuard.skipRouteChangeLog()
            call.resolve()
            return
        }

        do {
            try AudioRouteConfigurator.applyRecordingRoute(
                enableHQ: AudioRouteConfigurator.shouldUseHighQualityRoute()
            )
            call.resolve()
        } catch {
            call.reject("Failed to set recording route", error.localizedDescription)
        }
    }

    @objc func getPlaybackOutputProfile(_ call: CAPPluginCall) {
        let snapshot = AudioRouteConfigurator.routeSnapshot()
        var result = snapshot
        let headphonePorts: Set<String> = [
            AVAudioSession.Port.bluetoothA2DP.rawValue,
            AVAudioSession.Port.bluetoothHFP.rawValue,
            AVAudioSession.Port.bluetoothLE.rawValue,
            AVAudioSession.Port.headphones.rawValue,
            AVAudioSession.Port.headsetMic.rawValue,
            AVAudioSession.Port.airPlay.rawValue,
        ]
        let outputPort = snapshot["outputPort"] as? String ?? "unknown"
        result["usesHeadphones"] = headphonePorts.contains(outputPort)
        result["portType"] = outputPort
        call.resolve(result)
    }

    // MARK: - Native playback A/B test (AVPlayer — bypasses WKWebView / Web Audio)

    private func stopNativePlaybackTestPlayer() {
        if let nativeTestEndObserver = nativeTestEndObserver {
            NotificationCenter.default.removeObserver(nativeTestEndObserver)
            self.nativeTestEndObserver = nil
        }
        nativeTestPlayer?.pause()
        nativeTestPlayer = nil
    }

    private func applyCameraLikePlaybackSessionOrReject(_ call: CAPPluginCall) -> Bool {
        do {
            _ = try NativeCameraTestAudio.prepareCameraLikePlaybackSession()
            return true
        } catch {
            if CameraSessionGuard.shouldBlockRouteChanges() {
                CameraSessionGuard.skipRouteChangeLog()
            }
            call.reject("Failed to configure camera-like playback session", nil, error)
            return false
        }
    }

    private func finishPlaybackRouteIfNeeded() {
        guard playbackRouteRestorePending else { return }
        playbackRouteRestorePending = false
        CameraSessionGuard.setPlaybackRouteActive(false)
        nativeCameraEngine.runDeferredHealthCheckIfNeeded()

        print("[PlaybackRoute] playback ended")
        print("[PlaybackRoute] restoring camera session")

        do {
            try AudioRouteConfigurator.applyRecordingRoute(
                enableHQ: AudioRouteConfigurator.shouldUseHighQualityRoute()
            )
        } catch {
            print("[PlaybackRoute] failed to restore recording route: \(error.localizedDescription)")
        }

        notifyListeners("playbackRouteEnded", data: [:])
    }

    /// Defensive resync callable from JS on any foreground/idle-wake path. Cheap
    /// and idempotent: only rebuilds/restarts the native capture session when it
    /// should currently be active but AVFoundation left it stopped or invalid
    /// (phone lock, Control Center camera takeover, mediaServicesWereReset, long
    /// background idle). No-op if nothing native is active.
    @objc func ensureNativeCameraSessionHealthy(_ call: CAPPluginCall) {
        nativeCameraEngine.ensureSessionHealthy(reason: "js-request")
        call.resolve(CameraSessionGuard.snapshot())
    }

    @objc func setCameraSessionState(_ call: CAPPluginCall) {
        let previewActive = call.getBool("previewActive") ?? false
        let recordingActive = call.getBool("recordingActive") ?? false
        let recordingMode = call.getString("recordingMode") ?? "video"
        let youtubePlayAlongActive = call.getBool("youtubePlayAlongActive")

        CameraSessionGuard.setRecordingMode(recordingMode)

        if CameraSessionGuard.playbackRouteActive {
            // Metronome/playback can coexist with live camera — always honor mode
            // and promote preview/recording to true. Never demote to idle here;
            // stale JS snapshots during handoff must not clear a live bridge.
            if previewActive {
                CameraSessionGuard.setPreviewActive(true)
            }
            if recordingActive {
                CameraSessionGuard.setRecordingActive(true)
            }
            if let youtubePlayAlongActive {
                CameraSessionGuard.setYoutubePlayAlongActive(youtubePlayAlongActive)
            } else if !recordingActive {
                CameraSessionGuard.setYoutubePlayAlongActive(false)
            }
            call.resolve(CameraSessionGuard.snapshot())
            return
        }

        CameraSessionGuard.setPreviewActive(previewActive)
        CameraSessionGuard.setRecordingActive(recordingActive)
        if let youtubePlayAlongActive {
            CameraSessionGuard.setYoutubePlayAlongActive(youtubePlayAlongActive)
        } else if !recordingActive {
            CameraSessionGuard.setYoutubePlayAlongActive(false)
        }

        if !previewActive && !recordingActive && !CameraSessionGuard.playbackRouteActive {
            if nativeCameraEngine.requiresActiveAudioSession {
                call.resolve(CameraSessionGuard.snapshot())
                return
            }
            do {
                try AudioRouteConfigurator.deactivateCaptureSessionIfIdle()
            } catch {
                print("[AudioRoute] failed to deactivate idle capture session: \(error.localizedDescription)")
            }
        }

        call.resolve(CameraSessionGuard.snapshot())
    }

    @objc func getCameraSessionState(_ call: CAPPluginCall) {
        call.resolve(CameraSessionGuard.snapshot())
    }

    @objc func setPlaybackRouteActive(_ call: CAPPluginCall) {
        let active = call.getBool("active") ?? false
        CameraSessionGuard.setPlaybackRouteActive(active)
        if !active {
            // Playback just released AVAudioSession ownership — replay any
            // capture-session health check that was deferred while playback
            // owned the session, instead of leaving it unrecovered.
            nativeCameraEngine.runDeferredHealthCheckIfNeeded()
        }
        call.resolve(CameraSessionGuard.snapshot())
    }

    @objc func restoreRecordingRouteAfterPlayback(_ call: CAPPluginCall) {
        if playbackRouteRestorePending {
            finishPlaybackRouteIfNeeded()
        } else {
            print("[PlaybackRoute] playback ended")
            print("[PlaybackRoute] restoring camera session")
            do {
                try AudioRouteConfigurator.applyRecordingRoute(
                    enableHQ: AudioRouteConfigurator.shouldUseHighQualityRoute()
                )
            } catch {
                print("[PlaybackRoute] failed to restore recording route: \(error.localizedDescription)")
            }
        }
        call.resolve(AudioRouteConfigurator.routeSnapshot())
    }

    private func fileURL(from path: String?) -> URL? {
        guard let path = path, !path.isEmpty else { return nil }
        if let url = URL(string: path), url.isFileURL {
            return url
        }
        return URL(fileURLWithPath: path)
    }

    private func amplifiedExportURL(
        from sourceURL: URL,
        audioGain: Float,
        completion: @escaping (Result<URL, Error>) -> Void
    ) {
        guard audioGain > 1.01 else {
            completion(.success(sourceURL))
            return
        }

        let asset = AVURLAsset(url: sourceURL)
        guard !asset.tracks(withMediaType: .audio).isEmpty else {
            completion(.success(sourceURL))
            return
        }

        let composition = AVMutableComposition()

        do {
            for sourceTrack in asset.tracks(withMediaType: .video) {
                guard let compositionTrack = composition.addMutableTrack(
                    withMediaType: .video,
                    preferredTrackID: kCMPersistentTrackID_Invalid
                ) else { continue }
                try compositionTrack.insertTimeRange(
                    CMTimeRange(start: .zero, duration: asset.duration),
                    of: sourceTrack,
                    at: .zero
                )
                compositionTrack.preferredTransform = sourceTrack.preferredTransform
            }

            var audioParameters: [AVMutableAudioMixInputParameters] = []
            for sourceTrack in asset.tracks(withMediaType: .audio) {
                guard let compositionTrack = composition.addMutableTrack(
                    withMediaType: .audio,
                    preferredTrackID: kCMPersistentTrackID_Invalid
                ) else { continue }
                try compositionTrack.insertTimeRange(
                    CMTimeRange(start: .zero, duration: asset.duration),
                    of: sourceTrack,
                    at: .zero
                )
                let resolvedGain = min(max(audioGain, 1.0), 4.5)
                let parameters = AVMutableAudioMixInputParameters(track: compositionTrack)
                parameters.setVolume(resolvedGain, at: .zero)
                audioParameters.append(parameters)
            }

            guard let exportSession = AVAssetExportSession(
                asset: composition,
                presetName: AVAssetExportPresetHighestQuality
            ) else {
                completion(.success(sourceURL))
                return
            }

            let audioMix = AVMutableAudioMix()
            audioMix.inputParameters = audioParameters
            exportSession.audioMix = audioMix
            exportSession.outputFileType = .mp4
            exportSession.shouldOptimizeForNetworkUse = true

            let outputURL = FileManager.default.temporaryDirectory
                .appendingPathComponent("besttake-export-\(UUID().uuidString).mp4")
            try? FileManager.default.removeItem(at: outputURL)
            exportSession.outputURL = outputURL

            print("[NativeExport] audioGain requested=\(audioGain) applied=\(min(max(audioGain, 1.0), 4.5)) source=\(sourceURL.lastPathComponent)")

            exportSession.exportAsynchronously {
                DispatchQueue.main.async {
                    if exportSession.status == .completed {
                        completion(.success(outputURL))
                    } else if let error = exportSession.error {
                        completion(.failure(error))
                    } else {
                        completion(.success(sourceURL))
                    }
                }
            }
        } catch {
            completion(.failure(error))
        }
    }

    private func creatorStudioRenderSize(for aspectRatio: String) -> CGSize {
        switch aspectRatio {
        case "1:1":
            return CGSize(width: 1080, height: 1080)
        case "16:9":
            return CGSize(width: 1920, height: 1080)
        default:
            return CGSize(width: 1080, height: 1920)
        }
    }

    private func transformDictionary(_ object: [String: Any]) -> [String: Any] {
        return object["transform"] as? [String: Any] ?? [:]
    }

    private func percentValue(_ value: Any?, fallback: CGFloat) -> CGFloat {
        if let value = value as? Double { return CGFloat(value) }
        if let value = value as? NSNumber { return CGFloat(truncating: value) }
        return fallback
    }

    private func creatorStudioLayerFrame(
        object: [String: Any],
        renderSize: CGSize,
        defaultHeightRatio: CGFloat
    ) -> CGRect {
        let transform = transformDictionary(object)
        let widthPercent = percentValue(transform["width"], fallback: 70)
        let xPercent = percentValue(transform["x"], fallback: 50)
        let yPercent = percentValue(transform["y"], fallback: 50)
        let scale = max(0.1, percentValue(transform["scale"], fallback: 1))

        let width = renderSize.width * (widthPercent / 100) * scale
        let height = width * defaultHeightRatio
        let centerX = renderSize.width * (xPercent / 100)
        let centerY = renderSize.height * (yPercent / 100)
        return CGRect(x: centerX - width / 2, y: centerY - height / 2, width: width, height: height)
    }

    private func applyLayerRotation(_ layer: CALayer, object: [String: Any]) {
        let transform = transformDictionary(object)
        let degrees = percentValue(transform["rotation"], fallback: 0)
        guard abs(degrees) > 0.01 else { return }
        layer.setAffineTransform(CGAffineTransform(rotationAngle: degrees * .pi / 180))
    }

    private func imageForCreatorStudioAsset(path: String, fileType: String) -> UIImage? {
        guard let url = fileURL(from: path) else { return nil }
        if fileType == "pdf" {
            guard let document = PDFDocument(url: url), let page = document.page(at: 0) else {
                return nil
            }
            let bounds = page.bounds(for: .mediaBox)
            let scale: CGFloat = 2
            let size = CGSize(width: bounds.width * scale, height: bounds.height * scale)
            let renderer = UIGraphicsImageRenderer(size: size)
            return renderer.image { context in
                UIColor.white.set()
                context.fill(CGRect(origin: .zero, size: size))
                context.cgContext.saveGState()
                context.cgContext.translateBy(x: 0, y: size.height)
                context.cgContext.scaleBy(x: scale, y: -scale)
                page.draw(with: .mediaBox, to: context.cgContext)
                context.cgContext.restoreGState()
            }
        }
        return UIImage(contentsOfFile: url.path)
    }

    /// Undoes a track's `preferredTransform` (device-rotation metadata) so its
    /// pixels are in upright, natural orientation — shared by both the
    /// single-video Creator Studio transform and the multitrack grid transform.
    private func normalizedTrackOrientation(_ track: AVAssetTrack) -> (transform: CGAffineTransform, orientedSize: CGSize) {
        let preferred = track.preferredTransform
        let naturalRect = CGRect(origin: .zero, size: track.naturalSize).applying(preferred)
        let orientedSize = CGSize(width: abs(naturalRect.width), height: abs(naturalRect.height))
        let normalize = preferred.concatenating(
            CGAffineTransform(translationX: -naturalRect.origin.x, y: -naturalRect.origin.y)
        )
        return (normalize, orientedSize)
    }

    private func creatorStudioVideoTransform(
        track: AVAssetTrack,
        renderSize: CGSize
    ) -> CGAffineTransform {
        let (normalize, orientedSize) = normalizedTrackOrientation(track)
        let scale = max(renderSize.width / max(orientedSize.width, 1), renderSize.height / max(orientedSize.height, 1))
        let scaledSize = CGSize(width: orientedSize.width * scale, height: orientedSize.height * scale)
        let translate = CGAffineTransform(
            translationX: (renderSize.width - scaledSize.width) / 2,
            y: (renderSize.height - scaledSize.height) / 2
        )
        return normalize
            .concatenating(CGAffineTransform(scaleX: scale, y: scale))
            .concatenating(translate)
    }

    private func multitrackRectFrame(_ rectDict: [String: Any], renderSize: CGSize) -> CGRect {
        let xPercent = percentValue(rectDict["xPercent"], fallback: 0) / 100
        let yPercent = percentValue(rectDict["yPercent"], fallback: 0) / 100
        let widthPercent = percentValue(rectDict["widthPercent"], fallback: 100) / 100
        let heightPercent = percentValue(rectDict["heightPercent"], fallback: 100) / 100
        // Round shared boundaries, not widths independently. Adjacent cells now
        // land on the exact same output pixel and cannot expose a black seam.
        let minX = round(xPercent * renderSize.width)
        let minY = round(yPercent * renderSize.height)
        let maxX = round((xPercent + widthPercent) * renderSize.width)
        let maxY = round((yPercent + heightPercent) * renderSize.height)
        return CGRect(
            x: minX,
            y: minY,
            width: max(1, maxX - minX),
            height: max(1, maxY - minY)
        )
    }

    /// Aspect-fills a panel and returns a crop in the track's natural coordinate
    /// space. The crop prevents cover-scaled pixels from bleeding into a neighbor.
    private func multitrackVideoGeometry(
        track: AVAssetTrack,
        targetRect: CGRect
    ) -> (transform: CGAffineTransform, cropRect: CGRect) {
        let (normalize, orientedSize) = normalizedTrackOrientation(track)
        let sourceAspect = orientedSize.width / max(orientedSize.height, 1)
        let targetAspect = targetRect.width / max(targetRect.height, 1)
        let cropSize: CGSize
        if sourceAspect > targetAspect {
            cropSize = CGSize(width: orientedSize.height * targetAspect, height: orientedSize.height)
        } else {
            cropSize = CGSize(width: orientedSize.width, height: orientedSize.width / max(targetAspect, 0.0001))
        }
        let orientedCrop = CGRect(
            x: (orientedSize.width - cropSize.width) / 2,
            y: (orientedSize.height - cropSize.height) / 2,
            width: cropSize.width,
            height: cropSize.height
        )
        let naturalCrop = orientedCrop.applying(normalize.inverted()).standardized
        let scale = max(
            targetRect.width / max(orientedCrop.width, 1),
            targetRect.height / max(orientedCrop.height, 1)
        )
        let transform = normalize
            .concatenating(CGAffineTransform(
                translationX: -orientedCrop.origin.x,
                y: -orientedCrop.origin.y
            ))
            .concatenating(CGAffineTransform(scaleX: scale, y: scale))
            .concatenating(CGAffineTransform(
                translationX: targetRect.origin.x,
                y: targetRect.origin.y
            ))
        return (transform, naturalCrop)
    }

    private func addCreatorStudioObjectLayer(
        _ object: [String: Any],
        to overlayLayer: CALayer,
        renderSize: CGSize
    ) {
        guard let kind = object["kind"] as? String else { return }

        if kind == "sheetMusic" {
            guard
                let path = object["path"] as? String,
                let image = imageForCreatorStudioAsset(
                    path: path,
                    fileType: object["fileType"] as? String ?? "image"
                )
            else { return }
            let imageRatio = image.size.height / max(image.size.width, 1)
            let layer = CALayer()
            layer.contents = image.cgImage
            layer.contentsGravity = .resizeAspect
            layer.masksToBounds = true
            layer.cornerRadius = 18
            layer.borderColor = UIColor.white.withAlphaComponent(0.55).cgColor
            layer.borderWidth = 2
            layer.frame = creatorStudioLayerFrame(
                object: object,
                renderSize: renderSize,
                defaultHeightRatio: imageRatio
            )
            applyLayerRotation(layer, object: object)
            overlayLayer.addSublayer(layer)
            return
        }

        if kind == "text" || kind == "watermark" {
            guard let text = object["text"] as? String, !text.isEmpty else { return }
            let frame = creatorStudioLayerFrame(
                object: object,
                renderSize: renderSize,
                defaultHeightRatio: kind == "watermark" ? 0.28 : 0.22
            )
            let textLayer = CATextLayer()
            textLayer.frame = frame
            textLayer.string = text
            textLayer.alignmentMode = .center
            textLayer.contentsScale = UIScreen.main.scale
            textLayer.isWrapped = true
            textLayer.foregroundColor = UIColor.white.cgColor
            textLayer.shadowColor = UIColor.black.cgColor
            textLayer.shadowOpacity = 0.55
            textLayer.shadowRadius = 8
            textLayer.shadowOffset = CGSize(width: 0, height: 2)
            let fontSize = max(28, min(78, frame.height * 0.48))
            textLayer.font = UIFont.systemFont(ofSize: fontSize, weight: kind == "watermark" ? .bold : .heavy)
            textLayer.fontSize = fontSize

            if kind == "watermark" {
                textLayer.backgroundColor = UIColor.black.withAlphaComponent(0.34).cgColor
                textLayer.cornerRadius = frame.height / 2
                textLayer.masksToBounds = true
            }

            applyLayerRotation(textLayer, object: object)
            overlayLayer.addSublayer(textLayer)
        }
    }

    @objc func renderCreatorStudioVideo(_ call: CAPPluginCall) {
        guard let sourceURL = fileURL(from: call.getString("sourcePath")) else {
            call.reject("Missing source video")
            return
        }

        let aspectRatio = call.getString("aspectRatio") ?? "9:16"
        let renderSize = creatorStudioRenderSize(for: aspectRatio)
        let trimStartPercent = max(0, min(100, call.getDouble("trimStartPercent") ?? 0))
        let trimEndPercentRaw = call.getDouble("trimEndPercent")
        let trimEndPercent = trimEndPercentRaw == nil ? 100 : max(0, min(100, trimEndPercentRaw ?? 100))
        let audioGain = Float(call.getDouble("audioGain") ?? 1.0)
        let objects = call.getArray("objects", JSObject.self) ?? []

        let asset = AVURLAsset(url: sourceURL)
        guard let videoTrack = asset.tracks(withMediaType: .video).first else {
            call.reject("Source video has no video track")
            return
        }

        let durationSeconds = max(CMTimeGetSeconds(asset.duration), 0.01)
        let startSeconds = durationSeconds * trimStartPercent / 100
        let endSeconds = max(startSeconds + 0.05, durationSeconds * trimEndPercent / 100)
        let timeRange = CMTimeRange(
            start: CMTime(seconds: startSeconds, preferredTimescale: 600),
            end: CMTime(seconds: min(endSeconds, durationSeconds), preferredTimescale: 600)
        )

        let composition = AVMutableComposition()
        do {
            guard let compositionVideo = composition.addMutableTrack(
                withMediaType: .video,
                preferredTrackID: kCMPersistentTrackID_Invalid
            ) else {
                call.reject("Could not create video composition track")
                return
            }
            try compositionVideo.insertTimeRange(timeRange, of: videoTrack, at: .zero)

            var audioParameters: [AVMutableAudioMixInputParameters] = []
            for audioTrack in asset.tracks(withMediaType: .audio) {
                guard let compositionAudio = composition.addMutableTrack(
                    withMediaType: .audio,
                    preferredTrackID: kCMPersistentTrackID_Invalid
                ) else { continue }
                try compositionAudio.insertTimeRange(timeRange, of: audioTrack, at: .zero)
                let parameters = AVMutableAudioMixInputParameters(track: compositionAudio)
                parameters.setVolume(min(max(audioGain, 1.0), 4.5), at: .zero)
                audioParameters.append(parameters)
            }

            let instruction = AVMutableVideoCompositionInstruction()
            instruction.timeRange = CMTimeRange(start: .zero, duration: timeRange.duration)
            let layerInstruction = AVMutableVideoCompositionLayerInstruction(assetTrack: compositionVideo)
            layerInstruction.setTransform(
                creatorStudioVideoTransform(track: videoTrack, renderSize: renderSize),
                at: .zero
            )
            instruction.layerInstructions = [layerInstruction]

            let videoComposition = AVMutableVideoComposition()
            videoComposition.renderSize = renderSize
            videoComposition.frameDuration = CMTime(value: 1, timescale: 30)
            videoComposition.instructions = [instruction]

            let parentLayer = CALayer()
            parentLayer.frame = CGRect(origin: .zero, size: renderSize)
            parentLayer.isGeometryFlipped = true
            parentLayer.backgroundColor = UIColor.black.cgColor

            let videoLayer = CALayer()
            videoLayer.frame = parentLayer.bounds
            parentLayer.addSublayer(videoLayer)

            let overlayLayer = CALayer()
            overlayLayer.frame = parentLayer.bounds
            parentLayer.addSublayer(overlayLayer)

            for object in objects {
                let nativeObject = object as [String: Any]
                if nativeObject["kind"] as? String == "recording" { continue }
                addCreatorStudioObjectLayer(nativeObject, to: overlayLayer, renderSize: renderSize)
            }

            videoComposition.animationTool = AVVideoCompositionCoreAnimationTool(
                postProcessingAsVideoLayer: videoLayer,
                in: parentLayer
            )

            guard let exportSession = AVAssetExportSession(
                asset: composition,
                presetName: AVAssetExportPresetHighestQuality
            ) else {
                call.reject("Could not create export session")
                return
            }

            let audioMix = AVMutableAudioMix()
            audioMix.inputParameters = audioParameters
            exportSession.audioMix = audioMix
            exportSession.videoComposition = videoComposition
            exportSession.outputFileType = .mp4
            exportSession.shouldOptimizeForNetworkUse = true

            let outputURL = FileManager.default.temporaryDirectory
                .appendingPathComponent("besttake-creator-studio-\(UUID().uuidString).mp4")
            try? FileManager.default.removeItem(at: outputURL)
            exportSession.outputURL = outputURL

            print("[CreatorStudio] native render start objects=\(objects.count) aspect=\(aspectRatio) source=\(sourceURL.lastPathComponent)")
            exportSession.exportAsynchronously {
                DispatchQueue.main.async {
                    if exportSession.status == .completed {
                        print("[CreatorStudio] native render complete path=\(outputURL.path)")
                        call.resolve([
                            "success": true,
                            "path": outputURL.absoluteString
                        ])
                    } else if let error = exportSession.error {
                        print("[CreatorStudio] native render failed: \(error.localizedDescription)")
                        call.reject("Creator Studio render failed", error.localizedDescription)
                    } else {
                        call.reject("Creator Studio render failed")
                    }
                }
            }
        } catch {
            call.reject("Creator Studio render failed", error.localizedDescription)
        }
    }

    // MARK: - Multitrack grid export (N synced videos + optional sheet music + mixed audio)

    @objc func prepareMultitrackMonitor(_ call: CAPPluginCall) {
        let rawSources = call.getArray("sources", JSObject.self) ?? []
        var sources: [MultitrackTransportEngine.Source] = []

        for rawAny in rawSources {
            let raw = rawAny as [String: Any]
            guard
                let id = raw["id"] as? String,
                let path = raw["path"] as? String,
                let url = fileURL(from: path)
            else { continue }

            sources.append(
                MultitrackTransportEngine.Source(
                    id: id,
                    label: (raw["label"] as? String) ?? id,
                    url: url,
                    sourceInSec: max(0, (raw["sourceInSec"] as? NSNumber)?.doubleValue ?? 0),
                    sourceOutSec: (raw["sourceOutSec"] as? NSNumber)?.doubleValue,
                    timelineDelaySec: max(0, (raw["timelineDelaySec"] as? NSNumber)?.doubleValue ?? 0),
                    volume: Float((raw["volume"] as? NSNumber)?.doubleValue ?? 1),
                    muted: (raw["muted"] as? NSNumber)?.boolValue ?? false
                )
            )
        }

        DispatchQueue.global(qos: .userInitiated).async {
            do {
                let result = try MultitrackTransportEngine.shared.prepare(sources: sources)
                DispatchQueue.main.async { call.resolve(result) }
            } catch {
                DispatchQueue.main.async {
                    call.reject(error.localizedDescription, "MULTITRACK_MONITOR_PREPARE_FAILED")
                }
            }
        }
    }

    @objc func startMultitrackTransport(_ call: CAPPluginCall) {
        let bpm = call.getDouble("bpm") ?? 120
        let beatsPerBar = call.getInt("beatsPerBar") ?? 4
        let countInBars = call.getInt("countInBars") ?? 1
        let clickEnabled = call.getBool("clickEnabled") ?? true
        let soundId = call.getString("soundId") ?? "classic"

        DispatchQueue.global(qos: .userInitiated).async {
            do {
                let result = try MultitrackTransportEngine.shared.start(
                    bpm: bpm,
                    beatsPerBar: beatsPerBar,
                    countInBars: countInBars,
                    clickEnabled: clickEnabled,
                    soundId: soundId
                )
                self.nativeCameraEngine.setMultitrackPerformanceAnchor(
                    hostTimeSec: result.captureAlignmentHostTimeSec
                )
                DispatchQueue.main.async {
                    call.resolve([
                        "started": true,
                        "firstClickHostTimeSec": result.firstClickHostTimeSec,
                        "performanceHostTimeSec": result.performanceHostTimeSec,
                        "captureAlignmentHostTimeSec": result.captureAlignmentHostTimeSec,
                        "firstClickEpochMs": result.firstClickEpochMs,
                        "performanceEpochMs": result.performanceEpochMs,
                        "countInBeats": result.countInBeats,
                        "beatDurationSec": result.beatDurationSec,
                        "audibleSourceCount": result.audibleSourceCount,
                    ])
                }
            } catch {
                DispatchQueue.main.async {
                    call.reject(error.localizedDescription, "MULTITRACK_TRANSPORT_START_FAILED")
                }
            }
        }
    }

    @objc func stopMultitrackTransport(_ call: CAPPluginCall) {
        // `stop()` serializes behind any in-flight source extraction. Keep that
        // wait off Capacitor's UI/bridge thread when the user cancels arming.
        DispatchQueue.global(qos: .userInitiated).async {
            MultitrackTransportEngine.shared.stop()
            DispatchQueue.main.async {
                call.resolve(["stopped": true])
            }
        }
    }

    @objc func renderMultitrackVideo(_ call: CAPPluginCall) {
        let aspectRatio = call.getString("aspectRatio") ?? "9:16"
        let renderSize = creatorStudioRenderSize(for: aspectRatio)
        let durationHint = call.getDouble("durationSeconds") ?? 0
        let sources = call.getArray("sources", JSObject.self) ?? []

        guard !sources.isEmpty else {
            call.reject("No performance videos to export")
            return
        }

        let composition = AVMutableComposition()
        var layerInstructions: [AVMutableVideoCompositionLayerInstruction] = []
        var audioParameters: [AVMutableAudioMixInputParameters] = []
        var longestDuration = CMTime.zero

        for sourceAny in sources {
            let source = sourceAny as [String: Any]
            guard
                let path = source["path"] as? String,
                let sourceURL = fileURL(from: path),
                let rectDict = source["rect"] as? [String: Any]
            else { continue }

            let asset = AVURLAsset(url: sourceURL)
            guard let videoTrack = asset.tracks(withMediaType: .video).first else {
                print("[Multitrack] skipping unreadable source \(source["id"] ?? "?")")
                continue
            }

            guard let compositionVideo = composition.addMutableTrack(
                withMediaType: .video,
                preferredTrackID: kCMPersistentTrackID_Invalid
            ) else { continue }

            // Per-source trim: timeline 0 maps to trimStartSec inside the take,
            // and trimEndSec (if set) caps its contribution.
            let trimStartSec = (source["trimStartSec"] as? NSNumber)?.doubleValue ?? 0
            let trimEndSec = (source["trimEndSec"] as? NSNumber)?.doubleValue
            let timelineOffsetMs = (source["timelineOffsetMs"] as? NSNumber)?.doubleValue ?? 0
            
            // Must match live playback semantics (useMultitrackSync):
            // media time = timeline + trimStart + offset. Positive offset skips
            // the take's head (content plays earlier); negative offset delays
            // the clip's entry onto the timeline.
            var offsetInsertTime = CMTime.zero
            var adjustedTrimStart = trimStartSec
            if timelineOffsetMs > 0 {
                adjustedTrimStart += timelineOffsetMs / 1000.0
            } else if timelineOffsetMs < 0 {
                offsetInsertTime = CMTime(value: Int64(-timelineOffsetMs), timescale: 1000)
            }
            
            let assetSeconds = CMTimeGetSeconds(asset.duration)
            let clampedEnd = min(trimEndSec ?? assetSeconds, assetSeconds)
            let clampedStart = max(0, min(adjustedTrimStart, max(0, clampedEnd - 0.05)))
            let trimmedSeconds = max(0.05, clampedEnd - clampedStart)
            let sourceTimeRange = CMTimeRange(
                start: CMTime(seconds: clampedStart, preferredTimescale: 600),
                duration: CMTime(seconds: trimmedSeconds, preferredTimescale: 600)
            )
            do {
                try compositionVideo.insertTimeRange(sourceTimeRange, of: videoTrack, at: offsetInsertTime)
            } catch {
                print("[Multitrack] failed to insert video source \(source["id"] ?? "?"): \(error.localizedDescription)")
                continue
            }
            
            let endOnTimeline = CMTimeAdd(offsetInsertTime, sourceTimeRange.duration)
            longestDuration = CMTimeMaximum(longestDuration, endOnTimeline)

            let targetRect = multitrackRectFrame(rectDict, renderSize: renderSize)
            let layerInstruction = AVMutableVideoCompositionLayerInstruction(assetTrack: compositionVideo)
            let geometry = multitrackVideoGeometry(track: videoTrack, targetRect: targetRect)
            layerInstruction.setCropRectangle(geometry.cropRect, at: .zero)
            layerInstruction.setTransform(geometry.transform, at: .zero)
            layerInstructions.append(layerInstruction)

            // Mixer state from Play All — muted panels export silent, others at
            // their set gain. Unset volume defaults to unity (untouched panels
            // export exactly as before).
            let sourceMuted = (source["muted"] as? NSNumber)?.boolValue ?? false
            let sourceVolume = sourceMuted
                ? 0
                : Float((source["volume"] as? NSNumber)?.doubleValue ?? 1.0)

            for audioTrack in asset.tracks(withMediaType: .audio) {
                guard let compositionAudio = composition.addMutableTrack(
                    withMediaType: .audio,
                    preferredTrackID: kCMPersistentTrackID_Invalid
                ) else { continue }
                do {
                    try compositionAudio.insertTimeRange(sourceTimeRange, of: audioTrack, at: offsetInsertTime)
                    let parameters = AVMutableAudioMixInputParameters(track: compositionAudio)
                    parameters.setVolume(sourceVolume, at: .zero)
                    audioParameters.append(parameters)
                } catch {
                    print("[Multitrack] failed to insert audio for source \(source["id"] ?? "?"): \(error.localizedDescription)")
                }
            }
        }

        guard !layerInstructions.isEmpty else {
            call.reject("None of the panel videos could be read")
            return
        }

        if let backingDict = call.getObject("backingAudio"),
           let backingPath = backingDict["path"] as? String,
           let backingURL = fileURL(from: backingPath) {
            let backingAsset = AVURLAsset(url: backingURL)
            if let backingTrack = backingAsset.tracks(withMediaType: .audio).first {
                // Backing audio never extends the export past the panels' own
                // duration — trim it down if it's longer (e.g. a full song).
                let backingDuration = min(backingAsset.duration, longestDuration)
                let backingRange = CMTimeRange(start: .zero, duration: backingDuration)
                if let compositionBacking = composition.addMutableTrack(
                    withMediaType: .audio,
                    preferredTrackID: kCMPersistentTrackID_Invalid
                ) {
                    do {
                        try compositionBacking.insertTimeRange(backingRange, of: backingTrack, at: .zero)
                        let gain = Float(backingDict["gain"] as? Double ?? 1.0)
                        let parameters = AVMutableAudioMixInputParameters(track: compositionBacking)
                        parameters.setVolume(gain, at: .zero)
                        audioParameters.append(parameters)
                    } catch {
                        print("[Multitrack] failed to insert backing audio: \(error.localizedDescription)")
                    }
                }
            }
        }

        let instruction = AVMutableVideoCompositionInstruction()
        // Extend to the longest panel rather than crop to the shortest — a
        // panel that finished recording early just goes black/silent past its
        // own end instead of truncating footage from a longer panel.
        instruction.timeRange = CMTimeRange(start: .zero, duration: longestDuration)
        instruction.layerInstructions = layerInstructions

        let videoComposition = AVMutableVideoComposition()
        videoComposition.renderSize = renderSize
        videoComposition.frameDuration = CMTime(value: 1, timescale: 30)
        videoComposition.instructions = [instruction]

        let parentLayer = CALayer()
        parentLayer.frame = CGRect(origin: .zero, size: renderSize)
        parentLayer.isGeometryFlipped = true
        parentLayer.backgroundColor = UIColor.black.cgColor

        let videoLayer = CALayer()
        videoLayer.frame = parentLayer.bounds
        parentLayer.addSublayer(videoLayer)

        let decorationLayer = CALayer()
        decorationLayer.frame = parentLayer.bounds
        parentLayer.addSublayer(decorationLayer)

        // Draw every layout cell, including empty ones, so the final frame is a
        // deliberate connected grid instead of a set of floating rectangles.
        let gridRects = call.getArray("gridRects", JSObject.self) ?? []
        for rectAny in gridRects {
            let rect = rectAny as [String: Any]
            let borderLayer = CALayer()
            borderLayer.frame = multitrackRectFrame(rect, renderSize: renderSize)
            borderLayer.borderColor = UIColor.white.withAlphaComponent(0.42).cgColor
            borderLayer.borderWidth = 2
            decorationLayer.addSublayer(borderLayer)
        }

        // Sheet cue windows are expressed against the finished composition, so
        // the real composition length is what their key times are scaled by.
        let sheetTimelineDuration = max(CMTimeGetSeconds(longestDuration), durationHint)

        // One sheet layer builder, shared by the static image and by each timed
        // screenshot cue. Cues carry a window; the static case has none and
        // simply stays up for the whole render.
        func addSheetLayer(_ dict: [String: Any], window: (start: Double, end: Double?)?) {
            guard let sheetPath = dict["path"] as? String,
                  let sheetRectDict = dict["rect"] as? [String: Any],
                  let image = imageForCreatorStudioAsset(
                      path: sheetPath,
                      fileType: dict["fileType"] as? String ?? "image"
                  ) else { return }

            let fileType = dict["fileType"] as? String ?? "image"
            let requestedContentMode = dict["contentMode"] as? String
            // Existing image sessions have no contentMode. Default those to
            // fill as well, while PDFs keep their full-page fit behavior.
            let fillsViewport = fileType != "pdf" && requestedContentMode != "fit"
            let sheetFrame = multitrackRectFrame(sheetRectDict, renderSize: renderSize)
            let sheetViewport = CALayer()
            sheetViewport.frame = sheetFrame
            sheetViewport.backgroundColor = fillsViewport ? UIColor.black.cgColor : UIColor.white.cgColor
            sheetViewport.masksToBounds = true
            sheetViewport.borderColor = UIColor.white.withAlphaComponent(0.65).cgColor
            sheetViewport.borderWidth = 2

            let sheetLayer = CALayer()
            sheetLayer.frame = sheetViewport.bounds
            sheetLayer.contents = image.cgImage
            sheetLayer.contentsGravity = fillsViewport ? .resizeAspectFill : .resizeAspect
            let x = min(1.25, max(-0.25, (dict["x"] as? NSNumber)?.doubleValue ?? 0.5))
            let y = min(1.25, max(-0.25, (dict["y"] as? NSNumber)?.doubleValue ?? 0.5))
            let scale = min(2.5, max(0.6, (dict["scale"] as? NSNumber)?.doubleValue ?? 1))
            sheetLayer.position = CGPoint(
                x: sheetViewport.bounds.midX + (x - 0.5) * 0.7 * sheetViewport.bounds.width,
                y: sheetViewport.bounds.midY + (y - 0.5) * 0.7 * sheetViewport.bounds.height
            )
            sheetLayer.setAffineTransform(CGAffineTransform(scaleX: scale, y: scale))
            sheetViewport.addSublayer(sheetLayer)

            if let window = window, sheetTimelineDuration > 0 {
                // A hard opacity step (not a fade) reproduces the canvas cut.
                // The animation is anchored at AVCoreAnimationBeginTimeAtZero and
                // never removed, so it survives the whole offline render.
                let startFraction = min(1, max(0, window.start / sheetTimelineDuration))
                // Discrete keyframes take one MORE keyTime than value, starting
                // at 0 and ending at 1 — each value holds until the next time.
                var values: [NSNumber] = [0, 1]
                var keyTimes: [NSNumber] = [0, NSNumber(value: startFraction)]
                if let windowEnd = window.end, windowEnd < sheetTimelineDuration {
                    let endFraction = min(1, max(startFraction, windowEnd / sheetTimelineDuration))
                    values.append(0)
                    keyTimes.append(NSNumber(value: endFraction))
                }
                keyTimes.append(1)

                let animation = CAKeyframeAnimation(keyPath: "opacity")
                animation.calculationMode = .discrete
                animation.beginTime = AVCoreAnimationBeginTimeAtZero
                animation.duration = sheetTimelineDuration
                animation.isRemovedOnCompletion = false
                animation.fillMode = .both
                animation.values = values
                animation.keyTimes = keyTimes
                sheetViewport.opacity = startFraction <= 0 ? 1 : 0
                sheetViewport.add(animation, forKey: "sheetCueVisibility")
            }

            decorationLayer.addSublayer(sheetViewport)
        }

        let sheetMusicCues = call.getArray("sheetMusicCues", JSObject.self) ?? []
        if sheetMusicCues.count > 1 {
            for cueAny in sheetMusicCues {
                let cue = cueAny as [String: Any]
                let startSec = (cue["startSec"] as? NSNumber)?.doubleValue ?? 0
                let endSec = (cue["endSec"] as? NSNumber)?.doubleValue
                addSheetLayer(cue, window: (start: startSec, end: endSec))
            }
        } else if let sheetMusicDict = call.getObject("sheetMusic") {
            addSheetLayer(sheetMusicDict, window: nil)
        }

        videoComposition.animationTool = AVVideoCompositionCoreAnimationTool(
            postProcessingAsVideoLayer: videoLayer,
            in: parentLayer
        )

        guard let exportSession = AVAssetExportSession(
            asset: composition,
            presetName: AVAssetExportPresetHighestQuality
        ) else {
            call.reject("Could not create export session")
            return
        }

        let audioMix = AVMutableAudioMix()
        audioMix.inputParameters = audioParameters
        exportSession.audioMix = audioMix
        exportSession.videoComposition = videoComposition
        exportSession.outputFileType = .mp4
        exportSession.shouldOptimizeForNetworkUse = true

        let outputURL = FileManager.default.temporaryDirectory
            .appendingPathComponent("besttake-multitrack-\(UUID().uuidString).mp4")
        try? FileManager.default.removeItem(at: outputURL)
        exportSession.outputURL = outputURL

        print("[Multitrack] native render start sources=\(layerInstructions.count) aspect=\(aspectRatio) durationHint=\(durationHint)")
        exportSession.exportAsynchronously {
            DispatchQueue.main.async {
                if exportSession.status == .completed {
                    print("[Multitrack] native render complete path=\(outputURL.path)")
                    call.resolve([
                        "success": true,
                        "path": outputURL.absoluteString,
                        "durationSeconds": CMTimeGetSeconds(longestDuration)
                    ])
                } else if let error = exportSession.error {
                    print("[Multitrack] native render failed: \(error.localizedDescription)")
                    call.reject("Multitrack render failed", error.localizedDescription)
                } else {
                    call.reject("Multitrack render failed")
                }
            }
        }
    }

    @objc func shareMediaFile(_ call: CAPPluginCall) {
        guard let fileURL = fileURL(from: call.getString("path")) else {
            call.reject("Missing media file path")
            return
        }

        let title = call.getString("title") ?? fileURL.lastPathComponent
        let audioGain = Float(call.getDouble("audioGain") ?? 1.0)

        amplifiedExportURL(from: fileURL, audioGain: audioGain) { result in
            let shareURL: URL
            switch result {
            case .success(let url):
                shareURL = url
            case .failure(let error):
                print("[NativeExport] share gain export failed: \(error.localizedDescription)")
                shareURL = fileURL
            }

            // amplifiedExportURL's completion arrives on a background queue (the
            // AVAssetExportSession queue, or synchronously on the Capacitor
            // bridge queue for the unity-gain fast path). UIKit presentation MUST
            // happen on the main thread — presenting the share sheet off-main was
            // producing "UI API called on a background thread" / "Failed to
            // request default share mode" and a broken share sheet.
            DispatchQueue.main.async {
                guard let viewController = self.bridge?.viewController else {
                    call.reject("Unable to present share sheet")
                    return
                }

                let activityViewController = UIActivityViewController(
                    activityItems: [title, shareURL],
                    applicationActivities: nil
                )
                activityViewController.popoverPresentationController?.sourceView = viewController.view
                activityViewController.popoverPresentationController?.sourceRect = CGRect(
                    x: viewController.view.bounds.midX,
                    y: viewController.view.bounds.maxY - 1,
                    width: 1,
                    height: 1
                )
                activityViewController.completionWithItemsHandler = { _, completed, _, error in
                    if let error = error {
                        call.reject("Share failed", error.localizedDescription)
                        return
                    }
                    call.resolve([
                        "success": true,
                        "completed": completed
                    ])
                }

                viewController.present(activityViewController, animated: true)
            }
        }
    }

    @objc func saveVideoToPhotos(_ call: CAPPluginCall) {
        guard let fileURL = fileURL(from: call.getString("path")) else {
            call.reject("Missing video file path")
            return
        }
        let audioGain = Float(call.getDouble("audioGain") ?? 1.0)

        let performSave = { (saveURL: URL) in
            PHPhotoLibrary.shared().performChanges({
                PHAssetChangeRequest.creationRequestForAssetFromVideo(atFileURL: saveURL)
            }) { success, error in
                DispatchQueue.main.async {
                    if success {
                        call.resolve(["success": true])
                        return
                    }
                    call.reject("Save to Photos failed", error?.localizedDescription)
                }
            }
        }

        let prepareAndSave = {
            self.amplifiedExportURL(from: fileURL, audioGain: audioGain) { result in
                switch result {
                case .success(let saveURL):
                    performSave(saveURL)
                case .failure(let error):
                    print("[NativeExport] photos gain export failed: \(error.localizedDescription)")
                    performSave(fileURL)
                }
            }
        }

        if #available(iOS 14, *) {
            let status = PHPhotoLibrary.authorizationStatus(for: .addOnly)
            switch status {
            case .authorized, .limited:
                prepareAndSave()
            case .notDetermined:
                PHPhotoLibrary.requestAuthorization(for: .addOnly) { nextStatus in
                    if nextStatus == .authorized || nextStatus == .limited {
                        prepareAndSave()
                    } else {
                        call.reject("Photos permission denied")
                    }
                }
            default:
                call.reject("Photos permission denied")
            }
        } else {
            let status = PHPhotoLibrary.authorizationStatus()
            switch status {
            case .authorized:
                prepareAndSave()
            case .notDetermined:
                PHPhotoLibrary.requestAuthorization { nextStatus in
                    if nextStatus == .authorized {
                        prepareAndSave()
                    } else {
                        call.reject("Photos permission denied")
                    }
                }
            default:
                call.reject("Photos permission denied")
            }
        }
    }

    @objc func setNativeExperimentalAudioMode(_ call: CAPPluginCall) {
        let enabled = call.getBool("enabled") ?? false
        let selectedAudioEngine = call.getString("selectedAudioEngine") ?? (enabled ? "Native Experimental" : "Standard")
        let micInputPreference = AudioRouteConfigurator.parseMicInputPreference(call.getString("micInputPreference"))
        let recordingActive = call.getBool("recordingActive") ?? CameraSessionGuard.recordingActive
        let playbackActive = call.getBool("playbackActive") ?? CameraSessionGuard.playbackRouteActive

        // The audio-only recorder owns a stable PlayAndRecord session while it
        // writes. React state promotion (Listening -> Recording) can arrive
        // after the writer starts; never let that bookkeeping reconfigure the
        // session beneath an active take.
        if nativeCameraEngine.isAudioOnlyRecordingActive {
            var snapshot = AudioRouteConfigurator.routeSnapshot()
            snapshot["success"] = true
            snapshot["enabled"] = enabled
            snapshot["selectedAudioEngine"] = selectedAudioEngine
            snapshot["selectedMicPreference"] = micInputPreference.rawValue
            snapshot["recordingActive"] = true
            snapshot["playbackActive"] = playbackActive
            snapshot["nativeLoudnessProfile"] = "camera-input"
            snapshot["fallbackReason"] = "deferred while native audio recording is active"
            call.resolve(snapshot)
            return
        }

        do {
            let result = try AudioRouteConfigurator.applyNativeExperimentalAudioMode(
                enabled: enabled,
                selectedAudioEngine: selectedAudioEngine,
                micInputPreference: micInputPreference,
                recordingActive: recordingActive,
                playbackActive: playbackActive
            )
            call.resolve(result)
        } catch {
            var snapshot = AudioRouteConfigurator.routeSnapshot()
            snapshot["success"] = false
            snapshot["enabled"] = enabled
            snapshot["selectedAudioEngine"] = selectedAudioEngine
            snapshot["selectedMicPreference"] = micInputPreference.rawValue
            snapshot["recordingActive"] = recordingActive
            snapshot["playbackActive"] = playbackActive
            snapshot["fallbackReason"] = error.localizedDescription
            print("[NativeExperimentalAudio] failed: \(error.localizedDescription)")
            call.resolve(snapshot)
        }
    }

    @objc func startNativeCameraBridge(_ call: CAPPluginCall) {
        if CameraSessionGuard.recordingMode == "audio" {
            call.reject("startNativeCameraBridge blocked because active mode is Audio Mode")
            return
        }
        let useFrontCamera = call.getBool("useFrontCamera") ?? true
        let profile = NativeCameraAudioSessionProfile.parse(call.getString("audioSessionProfile"))
        let micPreference = AudioRouteConfigurator.parseMicInputPreference(call.getString("micInputPreference"))

        nativeCameraEngine.startBridgePreview(
            useFrontCamera: useFrontCamera,
            audioSessionProfile: profile,
            micInputPreference: micPreference,
            completion: { result in
                switch result {
                case .success(let payload):
                    call.resolve(payload)
                case .failure(let error):
                    call.reject("Native camera bridge failed", nil, error)
                }
            }
        )
    }

    @objc func stopNativeCameraBridge(_ call: CAPPluginCall) {
        nativeCameraEngine.stopBridgePreview {
            call.resolve()
        }
    }

    @objc func startNativeCameraPreview(_ call: CAPPluginCall) {
        if CameraSessionGuard.recordingMode == "audio" {
            call.reject("startNativeCameraPreview blocked because active mode is Audio Mode")
            return
        }
        let useFrontCamera = call.getBool("useFrontCamera") ?? true
        let profile = NativeCameraAudioSessionProfile.parse(call.getString("audioSessionProfile"))
        let micPreference = AudioRouteConfigurator.parseMicInputPreference(call.getString("micInputPreference"))

        DispatchQueue.main.async {
            guard let viewController = self.bridge?.viewController else {
                call.reject("Native preview container unavailable")
                return
            }

            guard let container = (viewController as? PortraitBridgeViewController)?.nativeCameraPreviewContainer
                ?? viewController.view else {
                call.reject("Native preview container unavailable")
                return
            }

            self.nativeCameraEngine.startPreview(
                in: container,
                useFrontCamera: useFrontCamera,
                audioSessionProfile: profile,
                micInputPreference: micPreference,
                completion: { result in
                    switch result {
                    case .success(let payload):
                        (self.bridge?.viewController as? PortraitBridgeViewController)?.setCameraPassthrough(true)
                        call.resolve(payload)
                    case .failure(let error):
                        (self.bridge?.viewController as? PortraitBridgeViewController)?.setCameraPassthrough(false)
                        call.reject("Native camera preview failed", nil, error)
                    }
                }
            )
        }
    }

    @objc func stopNativeCameraPreview(_ call: CAPPluginCall) {
        nativeCameraEngine.stopPreview {
            (self.bridge?.viewController as? PortraitBridgeViewController)?.setCameraPassthrough(false)
            call.resolve()
        }
    }

    @objc func setNativeCameraPassthrough(_ call: CAPPluginCall) {
        let enabled = call.getBool("enabled") ?? false
        DispatchQueue.main.async {
            (self.bridge?.viewController as? PortraitBridgeViewController)?.setCameraPassthrough(enabled)
            call.resolve()
        }
    }

    @objc func setNativeCameraFrameBridgeEnabled(_ call: CAPPluginCall) {
        let enabled = call.getBool("enabled") ?? false
        nativeCameraEngine.setFrameBridgeExternallyRequested(enabled)
        call.resolve()
    }

    @objc func ackNativeCameraPreviewFrame(_ call: CAPPluginCall) {
        guard let frameId = call.getInt("frameId"), frameId >= 0 else {
            call.reject("Missing frameId")
            return
        }
        nativeCameraEngine.acknowledgePreviewFrame(UInt64(frameId))
        call.resolve()
    }

    @objc func setNativeCameraPreviewZoom(_ call: CAPPluginCall) {
        let zoom = call.getDouble("zoom") ?? 1
        nativeCameraEngine.setPreviewZoom(CGFloat(zoom))
        call.resolve()
    }

    @objc func setNativeAudioTapEnabled(_ call: CAPPluginCall) {
        let enabled = call.getBool("enabled") ?? false
        jsAudioTapEnabled = enabled
        nativeCameraEngine.setAudioTapEnabled(enabled || spokenFeedbackActive)
        call.resolve()
    }

    @objc func getSpokenFeedbackPermission(_ call: CAPPluginCall) {
        let status: String
        switch SFSpeechRecognizer.authorizationStatus() {
        case .authorized: status = "granted"
        case .denied, .restricted: status = "denied"
        case .notDetermined: status = "prompt"
        @unknown default: status = "prompt"
        }
        call.resolve(["status": status])
    }

    @objc func startSpokenFeedback(_ call: CAPPluginCall) {
        let begin = { [weak self] in
            guard let self = self else {
                call.reject("Spoken feedback is unavailable")
                return
            }
            self.beginSpokenFeedback(call)
        }

        if SFSpeechRecognizer.authorizationStatus() == .authorized {
            DispatchQueue.main.async(execute: begin)
            return
        }

        SFSpeechRecognizer.requestAuthorization { status in
            DispatchQueue.main.async {
                guard status == .authorized else {
                    call.reject("Speech recognition permission was not granted")
                    return
                }
                begin()
            }
        }
    }

    @objc func stopSpokenFeedback(_ call: CAPPluginCall) {
        let transcript = spokenFeedbackTranscript
        finishSpokenFeedback(cancel: false)
        call.resolve(["transcript": transcript])
    }

    private func beginSpokenFeedback(_ call: CAPPluginCall) {
        finishSpokenFeedback(cancel: true)
        guard let recognizer = SFSpeechRecognizer(locale: Locale.current), recognizer.isAvailable else {
            call.reject("Speech recognition is temporarily unavailable")
            return
        }

        let request = SFSpeechAudioBufferRecognitionRequest()
        request.shouldReportPartialResults = true
        if #available(iOS 16.0, *) {
            request.addsPunctuation = true
        }
        spokenFeedbackRequest = request
        spokenFeedbackTranscript = ""
        spokenFeedbackActive = true
        nativeCameraEngine.setAudioTapEnabled(true)

        spokenFeedbackTask = recognizer.recognitionTask(with: request) { [weak self] result, error in
            guard let self = self else { return }
            if let result = result {
                let transcript = result.bestTranscription.formattedString
                self.spokenFeedbackTranscript = transcript
                DispatchQueue.main.async {
                    self.notifyListeners("spokenFeedbackResult", data: [
                        "transcript": transcript,
                        "isFinal": result.isFinal,
                    ])
                }
                if result.isFinal {
                    self.finishSpokenFeedback(cancel: false)
                }
            } else if let error = error, self.spokenFeedbackActive {
                DispatchQueue.main.async {
                    self.notifyListeners("spokenFeedbackError", data: [
                        "message": error.localizedDescription,
                    ])
                }
                self.finishSpokenFeedback(cancel: true)
            }
        }
        call.resolve(["active": true])
    }

    private func finishSpokenFeedback(cancel: Bool) {
        let request = spokenFeedbackRequest
        let task = spokenFeedbackTask
        spokenFeedbackRequest = nil
        spokenFeedbackTask = nil
        spokenFeedbackActive = false
        if cancel {
            task?.cancel()
        } else {
            request?.endAudio()
            task?.finish()
        }
        nativeCameraEngine.setAudioTapEnabled(jsAudioTapEnabled)
    }

    private func appendSpokenFeedbackAudio(
        pcmBase64: String,
        sampleRate: Double,
        sampleCount: Int
    ) {
        guard spokenFeedbackActive, let request = spokenFeedbackRequest,
              let data = Data(base64Encoded: pcmBase64), sampleCount > 0,
              let format = AVAudioFormat(
                commonFormat: .pcmFormatFloat32,
                sampleRate: sampleRate,
                channels: 1,
                interleaved: false
              ),
              let buffer = AVAudioPCMBuffer(
                pcmFormat: format,
                frameCapacity: AVAudioFrameCount(sampleCount)
              ),
              let destination = buffer.floatChannelData?[0] else { return }

        buffer.frameLength = AVAudioFrameCount(sampleCount)
        data.withUnsafeBytes { rawBuffer in
            guard let source = rawBuffer.bindMemory(to: Float.self).baseAddress else { return }
            destination.update(from: source, count: min(sampleCount, data.count / MemoryLayout<Float>.size))
        }
        spokenFeedbackQueue.async { [weak self, weak request] in
            guard let self = self,
                  let request = request,
                  self.spokenFeedbackActive,
                  self.spokenFeedbackRequest === request else { return }
            request.append(buffer)
        }
    }

    @objc func enhanceTakeAudio(_ call: CAPPluginCall) {
        guard let fileURL = resolvePluginFileURL(from: call) else { return }
        guard let paramsDict = call.getObject("params"),
              let params = AudioEnhancerParams.parse(paramsDict) else {
            call.reject("Invalid enhancer params")
            return
        }
        let isVideo = (call.getString("mediaType") ?? "video") == "video"

        AudioEnhancerRenderer.enhanceInPlace(
            fileURL: fileURL,
            isVideo: isVideo,
            params: params
        ) { result in
            switch result {
            case .success(let payload):
                call.resolve(payload)
            case .failure(let error):
                call.reject("Audio enhancement failed", nil, error)
            }
        }
    }

    @objc func startNativeTunerMonitor(_ call: CAPPluginCall) {
        let micPreference = AudioRouteConfigurator.parseMicInputPreference(
            call.getString("micInputPreference")
        )
        nativeCameraEngine.startTunerMonitor(
            micInputPreference: micPreference,
            completion: { result in
                switch result {
                case .success(let payload):
                    call.resolve(payload)
                case .failure(let error):
                    call.reject("Native tuner monitor failed", nil, error)
                }
            }
        )
    }

    @objc func stopNativeTunerMonitor(_ call: CAPPluginCall) {
        nativeCameraEngine.stopTunerMonitor { captureStillActive in
            call.resolve(["active": captureStillActive])
        }
    }

    /** Replaces a recorded take only after AVFoundation has exported the selected range. */
    @objc func trimTakeMedia(_ call: CAPPluginCall) {
        guard let sourceURL = resolvePluginFileURL(from: call) else { return }

        let asset = AVURLAsset(url: sourceURL)
        let duration = CMTimeGetSeconds(asset.duration)
        guard duration.isFinite, duration > 0 else {
            call.reject("The take has no playable duration")
            return
        }

        let startTime = max(0, min(call.getDouble("startTime") ?? 0, duration))
        let requestedEndTime = call.getDouble("endTime") ?? duration
        let endTime = max(startTime, min(requestedEndTime, duration))
        let trimmedDuration = endTime - startTime
        guard trimmedDuration >= 0.1 else {
            call.reject("Keep at least a tenth of a second in the trimmed take")
            return
        }

        let hasVideo = !asset.tracks(withMediaType: .video).isEmpty
        let preset = hasVideo ? AVAssetExportPresetHighestQuality : AVAssetExportPresetAppleM4A
        guard let exportSession = AVAssetExportSession(asset: asset, presetName: preset) else {
            call.reject("Could not create a trim export session")
            return
        }

        let outputType: AVFileType = hasVideo ? .mp4 : .m4a
        guard exportSession.supportedFileTypes.contains(outputType) else {
            call.reject("This take format cannot be trimmed on this device")
            return
        }

        let extensionName = hasVideo ? "mp4" : "m4a"
        let outputURL = sourceURL
            .deletingLastPathComponent()
            .appendingPathComponent(".besttake-trim-\(UUID().uuidString).\(extensionName)")
        try? FileManager.default.removeItem(at: outputURL)

        exportSession.outputURL = outputURL
        exportSession.outputFileType = outputType
        exportSession.shouldOptimizeForNetworkUse = true
        exportSession.timeRange = CMTimeRange(
            start: CMTime(seconds: startTime, preferredTimescale: 600),
            duration: CMTime(seconds: trimmedDuration, preferredTimescale: 600)
        )

        print("[TakeTrim] export start source=\(sourceURL.lastPathComponent) start=\(startTime) end=\(endTime)")
        exportSession.exportAsynchronously {
            DispatchQueue.main.async {
                guard exportSession.status == .completed else {
                    try? FileManager.default.removeItem(at: outputURL)
                    call.reject("Take trim export failed", exportSession.error?.localizedDescription)
                    return
                }

                do {
                    // replaceItemAt preserves the original unless the finished export is ready.
                    _ = try FileManager.default.replaceItemAt(sourceURL, withItemAt: outputURL)
                    print("[TakeTrim] export complete source=\(sourceURL.lastPathComponent) duration=\(trimmedDuration)")
                    call.resolve(["duration": trimmedDuration])
                } catch {
                    try? FileManager.default.removeItem(at: outputURL)
                    call.reject("Could not replace the original take after trimming", nil, error)
                }
            }
        }
    }

    @objc func prepareCameraLikePlaybackSession(_ call: CAPPluginCall) {
        let allowWithActivePreview = call.getBool("allowWithActivePreview") ?? false
        do {
            let result = try NativeCameraTestAudio.prepareCameraLikePlaybackSession(
                allowWithActivePreview: allowWithActivePreview
            )
            call.resolve(result)
        } catch {
            call.reject("Failed to prepare camera-like playback session", nil, error)
        }
    }

    private func resolvePluginFileURL(from call: CAPPluginCall) -> URL? {
        guard let urlString = call.getString("url"), !urlString.isEmpty else {
            call.reject("url required")
            return nil
        }

        if urlString.hasPrefix("file://") {
            guard let parsed = URL(string: urlString) else {
                call.reject("invalid file url")
                return nil
            }
            return parsed
        }

        return URL(fileURLWithPath: urlString)
    }

    private func startNativeAVPlayerPlayback(
        fileURL: URL,
        call: CAPPluginCall,
        logLabel: String,
        postProcess: Bool = false
    ) {
        if !CameraSessionGuard.playbackSessionPrepared {
            guard applyCameraLikePlaybackSessionOrReject(call) else { return }
        }

        var session = AVAudioSession.sharedInstance()
        if CameraSessionGuard.needsCoexistentPlaybackRoute
            || AudioRouteConfigurator.hasExternalOutput(session) {
            _ = try? AudioRouteConfigurator.applyCoexistentPlaybackSpeakerRoute()
        } else {
            _ = try? AudioRouteConfigurator.applyWebPlaybackRoute(webPlaybackActive: true)
        }
        session = AVAudioSession.sharedInstance()

        let item = AVPlayerItem(url: fileURL)
        let player = AVPlayer(playerItem: item)
        player.volume = 1.0

        let routeSnapshot = AudioRouteConfigurator.routeSnapshot(for: session)
        let route = routeSnapshot["outputPort"] as? String ?? "unknown"
        let systemVolume = session.outputVolume
        let durationSeconds = CMTimeGetSeconds(item.asset.duration)
        let safeDuration = durationSeconds.isFinite && durationSeconds > 0 ? durationSeconds : 0

        print("[\(logLabel)] started")
        print("[PlaybackRoute] playback started")
        print("[\(logLabel)] fileURL = \(fileURL.absoluteString)")
        print("[\(logLabel)] duration = \(safeDuration)")
        print("[\(logLabel)] route = \(route)")
        print("[\(logLabel)] systemVolume = \(systemVolume)")
        print("[\(logLabel)] playerVolume = \(player.volume)")

        playbackRouteRestorePending = true
        nativeTestPlayer = player
        nativeTestEndObserver = NotificationCenter.default.addObserver(
            forName: .AVPlayerItemDidPlayToEndTime,
            object: item,
            queue: .main
        ) { [weak self] _ in
            guard let self = self else { return }
            print("[\(logLabel)] finished")
            self.stopNativePlaybackTestPlayer()
            self.finishPlaybackRouteIfNeeded()
        }

        var payload: [String: Any] = [
            "fileURL": fileURL.absoluteString,
            "duration": safeDuration,
            "route": route,
            "systemVolume": systemVolume,
            "playerVolume": player.volume,
        ]
        if postProcess {
            payload["postProcess"] = true
        }

        let startSeconds = call.getDouble("startTime") ?? 0
        let beginPlayback = {
            player.play()
            call.resolve(payload)
        }

        if startSeconds > 0 {
            let seekTime = CMTime(seconds: startSeconds, preferredTimescale: 600)
            player.seek(to: seekTime, toleranceBefore: .zero, toleranceAfter: .zero) { _ in
                beginPlayback()
            }
        } else {
            beginPlayback()
        }
    }

    @objc func startNativePlaybackTest(_ call: CAPPluginCall) {
        guard let fileURL = resolvePluginFileURL(from: call) else { return }
        stopNativePlaybackTestPlayer()
        startNativeAVPlayerPlayback(fileURL: fileURL, call: call, logLabel: "NativePlaybackTest")
    }

    @objc func stopNativePlaybackTest(_ call: CAPPluginCall) {
        let wasPlaying = nativeTestPlayer != nil
        stopNativePlaybackTestPlayer()
        if wasPlaying {
            finishPlaybackRouteIfNeeded()
            print("[NativePlaybackTest] stopped")
        }
        call.resolve()
    }

    // MARK: - BestTakeBox inline preview (AVPlayer overlay — bypasses WKWebView video decode)

    private func inlineTakeBoxFrame(from call: CAPPluginCall) -> CGRect? {
        guard let x = call.getDouble("x"),
              let y = call.getDouble("y"),
              let width = call.getDouble("width"),
              let height = call.getDouble("height"),
              width > 0,
              height > 0 else {
            return nil
        }
        return CGRect(x: x, y: y, width: width, height: height)
    }

    @objc func startInlineTakeBoxPlayback(_ call: CAPPluginCall) {
        guard let fileURL = resolvePluginFileURL(from: call) else { return }
        guard let frame = inlineTakeBoxFrame(from: call) else {
            call.reject("layout x/y/width/height required")
            return
        }

        let mirror = call.getBool("mirror") ?? false
        let volume = Float(call.getFloat("volume") ?? 1)
        let audioOnly = call.getBool("audioOnly") ?? false
        let loudnessGainDb = Float(call.getDouble("loudnessGainDb") ?? 0)
        let ownerId = call.getString("ownerId") ?? ""
        let cornerRadius = CGFloat(call.getFloat("cornerRadius") ?? 0)
        let startTime = max(0, call.getDouble("startTime") ?? 0)

        DispatchQueue.main.async { [weak self] in
            guard let self = self else { return }
            do {
                // JS awaits enableStereoPlayback before calling here, but re-assert
                // the live session right before AVPlayer starts so take audio is not
                // silent when YouTube/WebKit already owns the mixable capture session.
                let session = AVAudioSession.sharedInstance()
                if CameraSessionGuard.needsCoexistentPlaybackRoute
                    || AudioRouteConfigurator.hasExternalOutput(session) {
                    _ = try AudioRouteConfigurator.applyCoexistentPlaybackSpeakerRoute()
                } else {
                    try AudioRouteConfigurator.ensureSessionActive(
                        session,
                        caller: "startInlineTakeBoxPlayback"
                    )
                }
                AudioRouteConfigurator.logMicRouteProof(context: "inlineTakeBoxPlaybackStart")

                let payload = try InlineTakeBoxPlaybackController.shared.start(
                    plugin: self,
                    fileURL: fileURL,
                    frameInWindow: frame,
                    mirror: mirror,
                    volume: volume,
                    ownerId: ownerId,
                    cornerRadius: cornerRadius,
                    startTime: startTime,
                    audioOnly: audioOnly,
                    loudnessGainDb: loudnessGainDb
                )
                call.resolve(payload)
            } catch {
                call.reject("Failed to start inline take box playback", nil, error)
            }
        }
    }

    @objc func stopInlineTakeBoxPlayback(_ call: CAPPluginCall) {
        let notify = call.getBool("notify") ?? true
        DispatchQueue.main.async {
            InlineTakeBoxPlaybackController.shared.stop(notify: notify)
            call.resolve()
        }
    }

    @objc func updateInlineTakeBoxPlaybackLayout(_ call: CAPPluginCall) {
        guard let frame = inlineTakeBoxFrame(from: call) else {
            call.reject("layout x/y/width/height required")
            return
        }
        DispatchQueue.main.async { [weak self] in
            guard let self = self else { return }
            let cornerRadius = CGFloat(call.getFloat("cornerRadius") ?? 0)
            InlineTakeBoxPlaybackController.shared.updateLayout(
                plugin: self,
                frameInWindow: frame,
                cornerRadius: cornerRadius > 0 ? cornerRadius : nil
            )
            call.resolve()
        }
    }

    @objc func setInlineTakeBoxPlaybackVolume(_ call: CAPPluginCall) {
        let volume = Float(call.getFloat("volume") ?? 1)
        DispatchQueue.main.async {
            InlineTakeBoxPlaybackController.shared.setVolume(volume)
            call.resolve()
        }
    }

    // MARK: - Native camera recording A/B test (AVCaptureSession — bypasses WKWebView)

    @objc func startNativeCameraRecording(_ call: CAPPluginCall) {
        if CameraSessionGuard.recordingMode == "audio" {
            call.reject("startNativeCameraRecording blocked because active mode is Audio Mode")
            return
        }
        let useFrontCamera = call.getBool("useFrontCamera") ?? true
        let profile = NativeCameraAudioSessionProfile.parse(call.getString("audioSessionProfile"))
        let micPreference = AudioRouteConfigurator.parseMicInputPreference(call.getString("micInputPreference"))

        nativeCameraEngine.start(
            useFrontCamera: useFrontCamera,
            audioSessionProfile: profile,
            micInputPreference: micPreference,
            completion: { result in
                switch result {
                case .success(let payload):
                    call.resolve(payload)
                case .failure(let error):
                    call.reject("Native camera recording failed", nil, error)
                }
            }
        )
    }

    @objc func stopNativeCameraRecording(_ call: CAPPluginCall) {
        let trimStartMs = call.getInt("trimStartMs") ?? 0
        nativeCameraEngine.stop(trimStartMs: trimStartMs, completion: { result in
            switch result {
            case .success(let payload):
                call.resolve(payload)
            case .failure(let error):
                call.reject("Native camera stop failed", nil, error)
            }
        })
    }

    @objc func startNativeAudioRecording(_ call: CAPPluginCall) {
        // Hands-free pre-roll starts before React has promoted its visual record
        // state, so the asynchronous camera-session sync can still report the
        // previous mode here. This audio-specific entry point is authoritative.
        // Do not reject a valid pre-roll because that bookkeeping is late.
        if CameraSessionGuard.recordingMode != "audio" {
            print("[NativeAudioRecording] correcting stale guard mode to audio before start")
        }
        CameraSessionGuard.setRecordingMode("audio")
        guard let takeId = call.getString("takeId"), !takeId.isEmpty else {
            call.reject("Missing takeId")
            return
        }
        let profile = NativeCameraAudioSessionProfile.parse(call.getString("audioSessionProfile"))
        let resolvedProfile: NativeCameraAudioSessionProfile =
            profile == .videoRecording ? .playAndRecordDefault : profile
        let micPreference = AudioRouteConfigurator.parseMicInputPreference(call.getString("micInputPreference"))

        nativeCameraEngine.startAudioRecording(
            takeId: takeId,
            audioSessionProfile: resolvedProfile,
            micInputPreference: micPreference,
            completion: { result in
                switch result {
                case .success(let payload):
                    call.resolve(payload)
                case .failure(let error):
                    call.reject("Native audio recording failed", nil, error)
                }
            }
        )
    }

    @objc func stopNativeAudioRecording(_ call: CAPPluginCall) {
        let trimStartMs = call.getInt("trimStartMs") ?? 0
        nativeCameraEngine.stopAudioRecording(trimStartMs: trimStartMs, completion: { result in
            switch result {
            case .success(let payload):
                call.resolve(payload)
            case .failure(let error):
                call.reject("Native audio stop failed", nil, error)
            }
        })
    }

    @objc func playNativeCameraTestPostProcess(_ call: CAPPluginCall) {
        guard let fileURL = resolvePluginFileURL(from: call) else { return }

        print("[NativeCameraTest] playNativeCameraTestPostProcess")
        print("[NativeCameraTest] fileURL = \(fileURL.absoluteString)")

        stopNativePlaybackTestPlayer()
        startNativeAVPlayerPlayback(
            fileURL: fileURL,
            call: call,
            logLabel: "NativeCameraTest",
            postProcess: true
        )
    }

    @objc func stopNativeCameraTestPostProcess(_ call: CAPPluginCall) {
        let wasPlaying = nativeTestPlayer != nil
        stopNativePlaybackTestPlayer()
        if wasPlaying {
            finishPlaybackRouteIfNeeded()
            print("[NativeCameraTest] post-process playback stopped")
        }
        call.resolve()
    }

    @objc func computeTakeAlignment(_ call: CAPPluginCall) {
        guard let path = call.getString("path"), let sourceURL = fileURL(from: path) else {
            call.reject("Missing or invalid path")
            return
        }
        let bpm = call.getDouble("bpm") ?? 0
        let countInBeats = call.getInt("countInBeats") ?? 0
        let deterministicOffsetMs = call.getDouble("deterministicOffsetMs") ?? 0
        let searchMs = call.getDouble("searchMs") ?? 250

        DispatchQueue.global(qos: .userInitiated).async {
            do {
                let (samples, sampleRate) = try NativeAudioDecoder.readMonoPCM(url: sourceURL)
                let result = TakeAlignmentEngine.compute(
                    samples: samples,
                    sampleRate: sampleRate,
                    bpm: bpm,
                    countInBeats: countInBeats,
                    deterministicOffsetMs: deterministicOffsetMs,
                    searchMs: searchMs
                )
                DispatchQueue.main.async {
                    call.resolve([
                        "refinedOffsetMs": result.refinedOffsetMs,
                        "residualMs": result.residualMs,
                        "confidence": result.confidence,
                        "applied": result.applied,
                    ])
                }
            } catch {
                DispatchQueue.main.async {
                    call.reject("Alignment failed", error.localizedDescription)
                }
            }
        }
    }

    @objc func extractWaveformPeaks(_ call: CAPPluginCall) {
        guard let path = call.getString("path"), let sourceURL = fileURL(from: path) else {
            call.reject("Missing or invalid path")
            return
        }
        let barCount = call.getInt("barCount") ?? 72

        DispatchQueue.global(qos: .userInitiated).async {
            do {
                let (samples, _) = try NativeAudioDecoder.readMonoPCM(url: sourceURL)
                let peaks = TakeAlignmentEngine.extractWaveformPeaks(samples: samples, barCount: barCount)
                DispatchQueue.main.async {
                    call.resolve(["peaks": peaks])
                }
            } catch {
                DispatchQueue.main.async {
                    call.reject("Waveform extract failed", error.localizedDescription)
                }
            }
        }
    }

    @objc func analyzePracticeTake(_ call: CAPPluginCall) {
        guard let path = call.getString("path"), let sourceURL = fileURL(from: path) else {
            call.reject("Missing or invalid path")
            return
        }

        DispatchQueue.global(qos: .utility).async {
            do {
                let (samples, sampleRate) = try NativeAudioDecoder.readMonoPCM(url: sourceURL)
                let analysis = TakeAlignmentEngine.analyzePracticeTake(
                    samples: samples,
                    sampleRate: sampleRate
                )
                DispatchQueue.main.async {
                    var payload: [String: Any] = [
                        "leadInMs": analysis.leadInMs,
                        "pitchSeries": analysis.pitchSeries,
                    ]
                    if let performanceStartSeconds = analysis.performanceStartSeconds {
                        payload["performanceStartSeconds"] = performanceStartSeconds
                    }
                    call.resolve(payload)
                }
            } catch {
                DispatchQueue.main.async {
                    call.reject("Practice analysis failed", error.localizedDescription)
                }
            }
        }
    }

    @objc func getAudioHardwareRtl(_ call: CAPPluginCall) {
        let session = AVAudioSession.sharedInstance()
        let rtl = (session.outputLatency + session.inputLatency + session.ioBufferDuration) * 1000.0
        call.resolve(["rtlMs": rtl])
    }

    @objc func getAudioOutputLatencyMs(_ call: CAPPluginCall) {
        let session = AVAudioSession.sharedInstance()
        let latencyMs = (session.outputLatency + session.ioBufferDuration) * 1000.0
        call.resolve(["latencyMs": latencyMs])
    }

    @objc func getRuntimeEnvironment(_ call: CAPPluginCall) {
        #if targetEnvironment(simulator)
        call.resolve(["isSimulator": true])
        #else
        call.resolve(["isSimulator": false])
        #endif
    }

    @objc func createSimulatorTake(_ call: CAPPluginCall) {
        #if targetEnvironment(simulator)
        let duration = min(30.0, max(0.6, call.getDouble("durationSeconds") ?? 1.0))
        DispatchQueue.global(qos: .userInitiated).async {
            do {
                let fileManager = FileManager.default
                let documents = try fileManager.url(
                    for: .documentDirectory,
                    in: .userDomainMask,
                    appropriateFor: nil,
                    create: true
                )
                let takesDirectory = documents.appendingPathComponent("takes", isDirectory: true)
                try fileManager.createDirectory(
                    at: takesDirectory,
                    withIntermediateDirectories: true,
                    attributes: nil
                )
                let filename = "simulator-\(UUID().uuidString).mp4"
                let outputURL = takesDirectory.appendingPathComponent(filename)
                let writer = try AVAssetWriter(outputURL: outputURL, fileType: .mp4)
                let width = 360
                let height = 640
                let framesPerSecond: Int32 = 10
                let videoInput = AVAssetWriterInput(
                    mediaType: .video,
                    outputSettings: [
                        AVVideoCodecKey: AVVideoCodecType.h264,
                        AVVideoWidthKey: width,
                        AVVideoHeightKey: height,
                    ]
                )
                videoInput.expectsMediaDataInRealTime = false
                let adaptor = AVAssetWriterInputPixelBufferAdaptor(
                    assetWriterInput: videoInput,
                    sourcePixelBufferAttributes: [
                        kCVPixelBufferPixelFormatTypeKey as String: kCVPixelFormatType_32BGRA,
                        kCVPixelBufferWidthKey as String: width,
                        kCVPixelBufferHeightKey as String: height,
                    ]
                )
                guard writer.canAdd(videoInput) else {
                    throw NSError(domain: "BestTakeSimulator", code: 1, userInfo: [
                        NSLocalizedDescriptionKey: "Unable to add the simulator video track."
                    ])
                }
                writer.add(videoInput)
                guard writer.startWriting() else {
                    throw writer.error ?? NSError(domain: "BestTakeSimulator", code: 2)
                }
                writer.startSession(atSourceTime: .zero)

                let frameCount = max(1, Int(ceil(duration * Double(framesPerSecond))))
                for frame in 0..<frameCount {
                    while !videoInput.isReadyForMoreMediaData {
                        Thread.sleep(forTimeInterval: 0.002)
                    }
                    guard let pool = adaptor.pixelBufferPool else {
                        throw NSError(domain: "BestTakeSimulator", code: 3)
                    }
                    var pixelBuffer: CVPixelBuffer?
                    let status = CVPixelBufferPoolCreatePixelBuffer(nil, pool, &pixelBuffer)
                    guard status == kCVReturnSuccess, let buffer = pixelBuffer else {
                        throw NSError(domain: "BestTakeSimulator", code: 4)
                    }
                    CVPixelBufferLockBaseAddress(buffer, [])
                    if let address = CVPixelBufferGetBaseAddress(buffer) {
                        memset(address, 0, CVPixelBufferGetDataSize(buffer))
                    }
                    CVPixelBufferUnlockBaseAddress(buffer, [])
                    let presentationTime = CMTime(value: CMTimeValue(frame), timescale: framesPerSecond)
                    guard adaptor.append(buffer, withPresentationTime: presentationTime) else {
                        throw writer.error ?? NSError(domain: "BestTakeSimulator", code: 5)
                    }
                }

                videoInput.markAsFinished()
                writer.finishWriting {
                    if let error = writer.error {
                        DispatchQueue.main.async {
                            call.reject("Simulator take creation failed", error.localizedDescription)
                        }
                        return
                    }
                    let size = (try? outputURL.resourceValues(forKeys: [.fileSizeKey]).fileSize) ?? 0
                    DispatchQueue.main.async {
                        call.resolve([
                            "filePath": "takes/\(filename)",
                            "fileURL": outputURL.absoluteString,
                            "duration": duration,
                            "fileSize": size,
                            "mimeType": "video/mp4",
                            "width": width,
                            "height": height,
                            "route": "simulator",
                            "hasAudioTrack": false,
                            "audioTrackCount": 0,
                        ])
                    }
                }
            } catch {
                DispatchQueue.main.async {
                    call.reject("Simulator take creation failed", error.localizedDescription)
                }
            }
        }
        #else
        call.reject("Simulator recording is only available in the iOS Simulator")
        #endif
    }
}
