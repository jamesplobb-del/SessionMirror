import type { PitchSample } from '../types'
import {
  MAX_INSTRUMENT_HZ,
  MIN_INSTRUMENT_HZ,
  NOTE_HYSTERESIS_CENTS,
  PITCH_SILENCE_FLOOR_CENTS,
  PITCH_SMOOTH_ALPHA,
} from './pitchConfig'

const A4_HZ = 440
const MAX_DISPLAY_CENTS = 50

export interface PitchReadout {
  noteName: string
  cents: number
  frequencyHz: number
  midi: number
}

export type IntonationZone = 'green' | 'yellow' | 'red'

const NOTE_NAMES = [
  'C',
  'C#',
  'D',
  'D#',
  'E',
  'F',
  'F#',
  'G',
  'G#',
  'A',
  'A#',
  'B',
] as const

export const TUNING_GREEN_CENTS = 5
export const TUNING_YELLOW_CENTS = 15

export function frequencyToMidi(frequencyHz: number): number {
  return 69 + 12 * Math.log2(frequencyHz / A4_HZ)
}

export function frequencyToNearestMidi(frequencyHz: number): number {
  return Math.round(frequencyToMidi(frequencyHz))
}

export function midiToNoteName(midi: number): string {
  const rounded = Math.round(midi)
  const pitchClass = ((rounded % 12) + 12) % 12
  const octave = Math.floor(rounded / 12) - 1
  return `${NOTE_NAMES[pitchClass]}${octave}`
}

export function centsFromMidi(frequencyHz: number, midi: number): number {
  const perfectHz = A4_HZ * 2 ** ((midi - 69) / 12)
  if (!Number.isFinite(perfectHz) || perfectHz <= 0 || frequencyHz <= 0) return 0
  return 1200 * Math.log2(frequencyHz / perfectHz)
}

/** Pick the best MIDI note for a frequency, optionally sticking to the prior note while in range. */
function bestMidiForFrequency(
  frequencyHz: number,
  preferMidi?: number | null,
): { midi: number; cents: number } {
  if (preferMidi != null && Number.isFinite(preferMidi)) {
    const stickyCents = centsFromMidi(frequencyHz, preferMidi)
    if (Math.abs(stickyCents) <= MAX_DISPLAY_CENTS) {
      return { midi: preferMidi, cents: stickyCents }
    }
  }

  const baseMidi = frequencyToNearestMidi(frequencyHz)
  let bestMidi = baseMidi
  let bestCents = centsFromMidi(frequencyHz, baseMidi)

  for (const shift of [-24, -12, 12, 24]) {
    const candidate = baseMidi + shift
    const cents = centsFromMidi(frequencyHz, candidate)
    if (Math.abs(cents) < Math.abs(bestCents)) {
      bestCents = cents
      bestMidi = candidate
    }
  }

  return { midi: bestMidi, cents: bestCents }
}

export function normalizeInstrumentFrequency(
  frequencyHz: number,
  minHz = MIN_INSTRUMENT_HZ,
  maxHz = MAX_INSTRUMENT_HZ,
): number {
  if (!Number.isFinite(frequencyHz) || frequencyHz <= 0) return 0

  let normalized = frequencyHz
  let guard = 0
  while (normalized < minHz && guard < 4) {
    normalized *= 2
    guard += 1
  }
  guard = 0
  while (normalized > maxHz && guard < 4) {
    normalized /= 2
    guard += 1
  }

  return normalized
}

export function frequencyToCentsOffset(frequencyHz: number): number {
  if (!Number.isFinite(frequencyHz) || frequencyHz <= 0) return 0
  return bestMidiForFrequency(frequencyHz).cents
}

export function frequencyToPitchReadout(
  frequencyHz: number,
  minHz = MIN_INSTRUMENT_HZ,
  maxHz = MAX_INSTRUMENT_HZ,
  preferMidi?: number | null,
): PitchReadout {
  if (!Number.isFinite(frequencyHz) || frequencyHz <= 0) {
    return { noteName: '—', cents: 0, frequencyHz: 0, midi: 0 }
  }

  const normalized = normalizeInstrumentFrequency(frequencyHz, minHz, maxHz)
  if (!isFrequencyInInstrumentRange(normalized, minHz, maxHz)) {
    return { noteName: '—', cents: 0, frequencyHz: 0, midi: 0 }
  }

  const { midi, cents } = bestMidiForFrequency(normalized, preferMidi)
  if (!Number.isFinite(cents) || Math.abs(cents) > MAX_DISPLAY_CENTS) {
    return { noteName: '—', cents: 0, frequencyHz: 0, midi: 0 }
  }

  return {
    noteName: midiToNoteName(midi),
    cents,
    frequencyHz: normalized,
    midi,
  }
}

export function stabilizePitchReadout(
  previous: PitchReadout | null,
  next: PitchReadout,
  noteHysteresisCents = NOTE_HYSTERESIS_CENTS,
): PitchReadout {
  if (next.noteName === '—' || !previous || previous.noteName === '—') {
    return next
  }

  if (previous.noteName === next.noteName) return next

  const centsFromPrevious = centsFromMidi(next.frequencyHz, previous.midi)
  if (Math.abs(centsFromPrevious) <= noteHysteresisCents) {
    return {
      ...next,
      noteName: previous.noteName,
      midi: previous.midi,
      cents: Math.max(-MAX_DISPLAY_CENTS, Math.min(MAX_DISPLAY_CENTS, centsFromPrevious)),
    }
  }

  return next
}

export function quantizeDisplayCents(cents: number, step: number): number {
  if (step <= 0) return cents
  return Math.round(cents / step) * step
}

/** RMS level of a time-domain audio buffer in decibels. */
export function bufferRmsDb(timeDomain: Float32Array): number {
  if (timeDomain.length === 0) return -100
  let sum = 0
  for (let index = 0; index < timeDomain.length; index += 1) {
    const sample = timeDomain[index]
    sum += sample * sample
  }
  const rms = Math.sqrt(sum / timeDomain.length)
  return 20 * Math.log10(Math.max(rms, 1e-8))
}

export function isSignalAboveRmsGate(timeDomain: Float32Array, gateDb: number): boolean {
  return bufferRmsDb(timeDomain) >= gateDb
}

/** Symmetric moving average — used for drawing smooth pitch curves. */
export function movingAverage(values: number[], radius: number): number[] {
  if (values.length === 0 || radius <= 0) return values

  return values.map((_, index) => {
    let sum = 0
    let count = 0
    for (
      let offset = Math.max(0, index - radius);
      offset <= Math.min(values.length - 1, index + radius);
      offset += 1
    ) {
      sum += values[offset]
      count += 1
    }
    return sum / count
  })
}

type Rgb = { r: number; g: number; b: number }

const LINE_GREEN: Rgb = { r: 34, g: 197, b: 94 }
const LINE_AMBER: Rgb = { r: 245, g: 158, b: 11 }
const LINE_RED: Rgb = { r: 239, g: 68, b: 68 }

const WASH_GREEN: Rgb = { r: 0, g: 184, b: 92 }
const WASH_AMBER: Rgb = { r: 240, g: 160, b: 0 }
const WASH_RED: Rgb = { r: 240, g: 51, b: 72 }

function mixRgb(from: Rgb, to: Rgb, amount: number): Rgb {
  const t = Math.max(0, Math.min(1, amount))
  return {
    r: from.r + (to.r - from.r) * t,
    g: from.g + (to.g - from.g) * t,
    b: from.b + (to.b - from.b) * t,
  }
}

function rgbToHex(color: Rgb): string {
  const channel = (value: number) => Math.round(value).toString(16).padStart(2, '0')
  return `#${channel(color.r)}${channel(color.g)}${channel(color.b)}`
}

function rgbToRgba(color: Rgb, alpha: number): string {
  return `rgba(${Math.round(color.r)}, ${Math.round(color.g)}, ${Math.round(color.b)}, ${alpha})`
}

/**
 * Continuous intonation mix: green in the pocket, orange-yellow when close,
 * then redder the farther sharp or flat you travel.
 */
function intonationRgb(absCents: number, green: Rgb, amber: Rgb, red: Rgb): Rgb {
  const abs = Math.max(0, Math.min(50, absCents))
  if (abs <= TUNING_GREEN_CENTS) {
    return mixRgb(green, amber, (abs / TUNING_GREEN_CENTS) * 0.06)
  }
  if (abs <= TUNING_YELLOW_CENTS) {
    const t = (abs - TUNING_GREEN_CENTS) / (TUNING_YELLOW_CENTS - TUNING_GREEN_CENTS)
    const eased = 1 - (1 - t) * (1 - t)
    return mixRgb(green, amber, 0.06 + eased * 0.94)
  }
  const t = Math.min(1, (abs - TUNING_YELLOW_CENTS) / 28)
  const eased = t ** 1.35
  return mixRgb(amber, red, eased)
}

export function getIntonationZone(cents: number): IntonationZone {
  const abs = Math.abs(cents)
  if (abs <= TUNING_GREEN_CENTS) return 'green'
  if (abs <= TUNING_YELLOW_CENTS) return 'yellow'
  return 'red'
}

export function getIntonationColor(cents: number): string {
  return rgbToHex(intonationRgb(Math.abs(cents), LINE_GREEN, LINE_AMBER, LINE_RED))
}

export function getIntonationWashHue(cents: number): string {
  return rgbToHex(intonationRgb(Math.abs(cents), WASH_GREEN, WASH_AMBER, WASH_RED))
}

export interface TunerWashTarget {
  hue: string
  strength: number
  feather: number
  darkStrength: number
  center: number
  rim: number
  rimGlow: number
  rimSpread: number
}

export const IDLE_TUNER_WASH: TunerWashTarget = {
  hue: '#1598ff',
  strength: 0,
  feather: 0,
  darkStrength: 22,
  center: 0,
  rim: 28,
  rimGlow: 18,
  rimSpread: 34,
}

/** Whole-screen wash that tracks the live line color, blooming on a held in-tune. */
export function getTunerWashTarget(
  cents: number | null,
  inTuneGlow = 0,
): TunerWashTarget {
  if (cents === null) return IDLE_TUNER_WASH

  const abs = Math.abs(cents)
  const hue = getIntonationWashHue(cents)
  const glow = Math.max(0, Math.min(1, inTuneGlow))

  if (abs <= TUNING_GREEN_CENTS) {
    return {
      hue,
      strength: 25 + glow * 17,
      feather: 8 + glow * 3,
      darkStrength: 36 + glow * 16,
      center: 32 + glow * 50,
      rim: 42 + glow * 24,
      rimGlow: 27 + glow * 19,
      rimSpread: 42 + glow * 40,
    }
  }

  if (abs <= TUNING_YELLOW_CENTS) {
    const close = (abs - TUNING_GREEN_CENTS) / (TUNING_YELLOW_CENTS - TUNING_GREEN_CENTS)
    return {
      hue,
      strength: 30 + close * 3,
      feather: 10,
      darkStrength: 42 + close * 2,
      center: 58 + close * 5,
      rim: 44 + close * 3,
      rimGlow: 30 + close * 3,
      rimSpread: 46 + close * 2,
    }
  }

  const far = Math.min(1, (abs - TUNING_YELLOW_CENTS) / 28)
  return {
    hue,
    strength: 35 + far * 8,
    feather: 10,
    darkStrength: 46 + far * 4,
    center: 64 + far * 5,
    rim: 49 + far * 7,
    rimGlow: 34 + far * 5,
    rimSpread: 54 + far * 10,
  }
}

export function isSilenceFloorSample(cents: number): boolean {
  return cents <= PITCH_SILENCE_FLOOR_CENTS + 0.5
}

export function getTraceColor(cents: number): string {
  if (isSilenceFloorSample(cents)) return 'rgba(255, 255, 255, 0.16)'
  return getIntonationColor(cents)
}

export function getTraceZone(cents: number): IntonationZone | 'silence' {
  if (isSilenceFloorSample(cents)) return 'silence'
  return getIntonationZone(cents)
}

/** Vertical cents gradient for pitch trace (sharp top → in-tune center → flat bottom). */
export function createPitchVerticalGradient(
  ctx: CanvasRenderingContext2D,
  centsToY: (cents: number) => number,
): CanvasGradient {
  const gradient = ctx.createLinearGradient(0, centsToY(50), 0, centsToY(-50))
  gradient.addColorStop(0, getIntonationColor(50))
  gradient.addColorStop(0.28, getIntonationColor(22))
  gradient.addColorStop(0.42, getIntonationColor(TUNING_YELLOW_CENTS))
  gradient.addColorStop(0.5, getIntonationColor(0))
  gradient.addColorStop(0.58, getIntonationColor(-TUNING_YELLOW_CENTS))
  gradient.addColorStop(0.72, getIntonationColor(-22))
  gradient.addColorStop(1, getIntonationColor(-50))
  return gradient
}

export function glowColorForCents(cents: number, alpha = 0.55): string {
  return rgbToRgba(intonationRgb(Math.abs(cents), LINE_GREEN, LINE_AMBER, LINE_RED), alpha)
}

export function formatFrequencyHz(frequencyHz: number): string {
  if (!Number.isFinite(frequencyHz) || frequencyHz <= 0) return '— Hz'
  return `${frequencyHz.toFixed(1)} Hz`
}

/** Human-readable cents for tuner readout (e.g. +3.5¢). */
export function formatDisplayCents(cents: number): string {
  if (!Number.isFinite(cents)) return '—'
  const rounded = Math.round(cents * 10) / 10
  const sign = rounded >= 0 ? '+' : ''
  return `${sign}${rounded.toFixed(1)}¢`
}

export function isInTune(cents: number, tolerance = TUNING_GREEN_CENTS): boolean {
  return Math.abs(cents) <= tolerance
}

/** Maps sustained in-tune glow (0–~1.6) to CSS/canvas-friendly glow styles. */
export function formatInTuneGlowStyles(glow: number): {
  textShadow: string
  filter: string
  ringStrokeWidth: number
  ringOpacity: number
  haloStrokeWidth: number
  haloOpacity: number
} {
  const clamped = Math.max(0, glow)
  const t = Math.min(1, clamped)
  const spread = 22 + clamped * 62
  const alpha = 0.42 + t * 0.58
  const outerAlpha = 0.2 + t * 0.38
  const farAlpha = 0.08 + t * 0.22
  return {
    textShadow: [
      `0 0 ${spread}px rgba(34, 197, 94, ${alpha})`,
      `0 0 ${spread * 1.6}px rgba(34, 197, 94, ${outerAlpha})`,
      `0 0 ${spread * 2.8}px rgba(34, 197, 94, ${farAlpha})`,
    ].join(', '),
    filter: [
      `drop-shadow(0 0 ${8 + clamped * 22}px rgba(34, 197, 94, ${0.38 + t * 0.55}))`,
      `drop-shadow(0 0 ${16 + clamped * 36}px rgba(34, 197, 94, ${0.18 + t * 0.35}))`,
    ].join(' '),
    ringStrokeWidth: 3 + clamped * 3.2,
    ringOpacity: 0.78 + t * 0.22,
    haloStrokeWidth: 10 + clamped * 18,
    haloOpacity: 0.06 + t * 0.14 + Math.min(0.08, clamped * 0.05),
  }
}

/** Sharp/flat ring arc emphasis from zone severity and |cents|. */
export function formatAccentOrbitArcStyle(
  accent: string,
  zone: IntonationZone,
  fillRatio: number,
): {
  minStroke: number
  maxStroke: number
  minOpacity: number
  filter: string
} {
  const severity = zone === 'red' ? 1 : zone === 'yellow' ? 0.65 : 0.4
  return {
    minStroke: 5 + severity * 1.5 + fillRatio * 1.2,
    maxStroke: 7.5 + severity * 3.5 + fillRatio * 2.5,
    minOpacity: 0.58 + severity * 0.08,
    filter: `drop-shadow(0 0 ${5 + severity * 8}px ${accent}) drop-shadow(0 0 ${10 + severity * 14}px ${accent}88)`,
  }
}

export function smoothFrequency(
  previous: number | null,
  next: number,
  alpha = PITCH_SMOOTH_ALPHA,
): number {
  if (previous == null || !Number.isFinite(previous) || previous <= 0) return next
  if (!Number.isFinite(next) || next <= 0) return previous
  return previous * (1 - alpha) + next * alpha
}

export function isFrequencyInInstrumentRange(
  frequencyHz: number,
  minHz = MIN_INSTRUMENT_HZ,
  maxHz = MAX_INSTRUMENT_HZ,
): boolean {
  return (
    Number.isFinite(frequencyHz) &&
    frequencyHz >= minHz &&
    frequencyHz <= maxHz
  )
}

export function interpolateFrequencyAtTime(
  samples: PitchSample[],
  time: number,
): number | null {
  if (samples.length === 0) return null
  if (time <= samples[0].time) return samples[0].frequencyHz
  if (time >= samples[samples.length - 1].time) {
    return samples[samples.length - 1].frequencyHz
  }

  for (let index = 0; index < samples.length - 1; index += 1) {
    const start = samples[index]
    const end = samples[index + 1]
    if (time >= start.time && time <= end.time) {
      const ratio = (time - start.time) / (end.time - start.time)
      return start.frequencyHz + ratio * (end.frequencyHz - start.frequencyHz)
    }
  }

  return null
}
