import { Capacitor } from '@capacitor/core'
import { Directory, Filesystem } from '@capacitor/filesystem'
import { initAppFilesystem, isFilesystemMissingError, nativeDataFileExists, TAKES_DIR } from './filesystemInit'
import type { CaptureProfile } from './audioCapture'
import type { RecordingCaptureDiagnostics, RecordingTrackSnapshot } from './recordingDiagnostics'
import type { PitchSample } from '../types'
import { reportError } from './crashReporting'

export const NATIVE_VIDEO_MIME = 'video/mp4'
export const NATIVE_AUDIO_MIME = 'audio/mp4'

export interface PersistedTakeVideo {
  filePath: string
  videoUrl: string
}

export interface RecordingCompletePayload {
  takeId: string
  mimeType: string
  mediaType: 'video' | 'audio'
  filePath: string
  videoUrl: string
  /** Recording length in whole seconds */
  durationSeconds: number
  /** Device orientation when recording started */
  recordingOrientation?: 'portrait' | 'landscape'
  /** Only set on web dev fallback — native recordings are already on disk */
  blob?: Blob
  captureProfile?: CaptureProfile
  captureTrackSnapshot?: RecordingTrackSnapshot | null
  /** Seconds from file start to the hands-free performance trigger. Not persisted. */
  autoPerformanceStartSeconds?: number
  /** Populated after post-save loudness analysis. */
  captureDiagnostics?: RecordingCaptureDiagnostics
  timelineOffsetMs?: number
  recordingBpm?: number
  performanceStartBeats?: number
  performanceStartOffsetBeats?: number
  referenceTrackId?: string
  referenceStartBeat?: number
  /** Simulator-only demo contour, or a contour supplied by another capture engine. */
  pitchSeries?: PitchSample[]
  /**
   * Overrides the default video mirror-on-playback behavior. Native camera
   * recordings are already saved in true (unmirrored) orientation, so they
   * must NOT be CSS-mirrored again at playback — leave undefined to keep the
   * default (mirrored) behavior for legacy WebKit-recorded takes.
   */
  mirrorPlayback?: boolean
}

/** Options passed when stopping a multitrack recording take. */
export interface MultitrackRecordingStopOptions {
  /** Legacy latency-based offset — RTL is subtracted before save. */
  rawOffsetMs?: number
  /** Source-in on the recorded file; native multitrack replaces estimates with its measured movie time. */
  timelineOffsetMs?: number
  recordingBpm?: number
  performanceStartBeats?: number
  performanceStartOffsetBeats?: number
  referenceTrackId?: string
  referenceStartBeat?: number
}

function extensionForMime(mimeType: string): string {
  if (mimeType.includes('audio/mp4') || mimeType.includes('m4a')) return 'm4a'
  if (mimeType.includes('mpeg') || mimeType.includes('mp3')) return 'mp3'
  if (mimeType.includes('audio') && mimeType.includes('webm')) return 'webm'
  if (mimeType.includes('mp4')) return 'mp4'
  if (mimeType.includes('webm')) return 'webm'
  return 'mp4'
}

export function normalizeBlobMime(mimeType: string): string {
  if (mimeType.includes('video/mp4')) return NATIVE_VIDEO_MIME
  if (mimeType.includes('audio/mp4')) return NATIVE_AUDIO_MIME
  return mimeType
}

export function composeBufferedRecordingBlob(chunks: Blob[], mimeType: string): Blob {
  const writeMime = normalizeBlobMime(mimeType)
  if (chunks.length <= 1) {
    return new Blob(chunks, { type: writeMime })
  }

  // iOS delivers the final complete MP4 fragment last; choosing by size can
  // select an earlier fragment whose video track stalls during playback.
  const primary = chunks[chunks.length - 1]!
  console.warn('[Recording] Multiple buffered MediaRecorder chunks — using final fragment', {
    chunkCount: chunks.length,
    chunkSizes: chunks.map((chunk) => chunk.size),
    selectedBytes: primary.size,
  })
  return new Blob([primary], { type: writeMime })
}

async function ensureTakesDirectory(): Promise<void> {
  await initAppFilesystem()
}

/** True when the URL is a WebView-safe Capacitor playback URL (never raw file://). */
export function isConvertedPlaybackUrl(url: string): boolean {
  if (!url || url.startsWith('file://')) {
    return false
  }
  return (
    url.startsWith('blob:') ||
    url.includes('_capacitor_file_') ||
    url.startsWith('capacitor://')
  )
}

/**
 * Strict final pass — every native file URI must go through convertFileSrc
 * before reaching `<video src>`. Never returns a raw file:// path.
 */
export function applyStrictPlaybackSrc(uri: string): string {
  if (!uri || !Capacitor.isNativePlatform()) {
    return uri
  }

  if (isConvertedPlaybackUrl(uri)) {
    return uri
  }

  const converted = Capacitor.convertFileSrc(uri)
  if (converted.startsWith('file://')) {
    return Capacitor.convertFileSrc(converted)
  }
  return converted
}

/** Returns null if the URL is still an unsafe raw file path on native. */
export function sanitizeNativeVideoSrc(url: string | null): string | null {
  if (!url) return null
  if (!Capacitor.isNativePlatform()) return url

  const safe = applyStrictPlaybackSrc(url)
  if (safe.startsWith('file://') || !isConvertedPlaybackUrl(safe)) {
    return null
  }
  return safe
}

/** @deprecated Use applyStrictPlaybackSrc */
export function convertFileSrcIfNeeded(uri: string): string {
  return applyStrictPlaybackSrc(uri)
}

/** In-memory cache so PiP / vault players don't hammer Filesystem.getUri. */
const playbackSrcCache = new Map<string, string>()

/** Drop cached capacitor URLs when a take file is removed or replaced. */
export function invalidatePlaybackSrcCache(filePath: string): void {
  if (!filePath) return

  const takeId = filePath.match(/\/([^/]+)\.[^.]+$/)?.[1]
  const keysToDelete = new Set<string>()

  for (const [key, value] of playbackSrcCache.entries()) {
    if (
      key === filePath ||
      key.includes(filePath) ||
      filePath.includes(key) ||
      (takeId !== undefined && (key.includes(takeId) || value.includes(takeId)))
    ) {
      keysToDelete.add(key)
    }
  }

  for (const key of keysToDelete) {
    playbackSrcCache.delete(key)
  }
}

/** Sync read when a take was just saved — avoids a black frame while getUri resolves. */
export function readCachedPlaybackSrc(
  filePath: string,
  fallbackUrl: string,
): string | null {
  if (!Capacitor.isNativePlatform()) {
    return fallbackUrl || null
  }

  const fromFallback = sanitizeNativeVideoSrc(fallbackUrl)
  if (fromFallback) return fromFallback

  for (const key of [filePath, fallbackUrl]) {
    if (!key) continue
    const cached = playbackSrcCache.get(key)
    if (cached) {
      const safe = sanitizeNativeVideoSrc(cached)
      if (safe) return safe
    }
  }

  return null
}

function rememberPlaybackSrc(filePath: string, videoUrl: string): string {
  const safe = sanitizeNativeVideoSrc(videoUrl) ?? applyStrictPlaybackSrc(videoUrl)
  if (filePath && safe) playbackSrcCache.set(filePath, safe)
  if (videoUrl && safe) playbackSrcCache.set(videoUrl, safe)
  return safe
}

/**
 * Resolve playback URL for native takes — cached, prefers already-converted videoUrl.
 */
export async function resolveNativeVideoPlaybackSrc(
  filePath: string,
  fallbackUrl: string,
): Promise<string | null> {
  if (!Capacitor.isNativePlatform()) {
    return fallbackUrl || null
  }

  if (isConvertedPlaybackUrl(fallbackUrl)) {
    const safe = sanitizeNativeVideoSrc(fallbackUrl)
    if (safe && filePath) rememberPlaybackSrc(filePath, safe)
    return safe
  }

  const cacheKey = filePath || fallbackUrl
  if (cacheKey) {
    const cached = playbackSrcCache.get(cacheKey)
    if (cached) {
      if (filePath && !(await nativeDataFileExists(filePath))) {
        invalidatePlaybackSrcCache(filePath)
      } else {
        return sanitizeNativeVideoSrc(cached)
      }
    }
  }

  let resolved = ''
  if (filePath) {
    resolved = await toCapacitorPlaybackSrc(filePath)
  } else if (fallbackUrl) {
    resolved = await toCapacitorPlaybackSrc(fallbackUrl)
  } else {
    return null
  }

  if (cacheKey && resolved) {
    playbackSrcCache.set(cacheKey, resolved)
  }

  return sanitizeNativeVideoSrc(resolved)
}

/**
 * Always returns a WebView-safe playback URL on native.
 * Handles relative paths, raw file:/// URIs, and pre-converted URLs.
 */
export async function toCapacitorPlaybackSrc(
  uriOrPath: string,
): Promise<string> {
  if (!uriOrPath) return ''

  if (!Capacitor.isNativePlatform()) {
    return uriOrPath
  }

  if (isConvertedPlaybackUrl(uriOrPath)) {
    return uriOrPath
  }

  const cached = playbackSrcCache.get(uriOrPath)
  if (cached) {
    const isRelativeTakePath = uriOrPath.includes('/') && !uriOrPath.startsWith('file://')
    if (!isRelativeTakePath || (await nativeDataFileExists(uriOrPath))) {
      return cached
    }
    invalidatePlaybackSrcCache(uriOrPath)
  }

  let converted = uriOrPath

  if (uriOrPath.startsWith('file://')) {
    converted = Capacitor.convertFileSrc(uriOrPath)
  } else {
    try {
      const { uri } = await Filesystem.getUri({
        path: uriOrPath,
        directory: Directory.Data,
      })
      converted = Capacitor.convertFileSrc(uri)
    } catch (err) {
      if (isFilesystemMissingError(err)) {
        return ''
      }
      return ''
    }
  }

  if (converted.startsWith('file://')) {
    converted = Capacitor.convertFileSrc(converted)
  }

  playbackSrcCache.set(uriOrPath, converted)
  return converted
}

/** Raw file:// URI for native AVPlayer — not the capacitor:// WebView URL. */
export async function resolveNativeFileUri(filePath: string): Promise<string> {
  if (!filePath) return ''
  if (filePath.startsWith('file://')) return filePath

  try {
    const { uri } = await Filesystem.getUri({
      path: filePath,
      directory: Directory.Data,
    })
    return uri
  } catch (err) {
    if (isFilesystemMissingError(err)) return ''
    return ''
  }
}

/**
 * Slice size for incremental writes.
 *
 * Base64-encoding a whole recording produces a single JS string roughly 1.37x
 * the file size, on top of the blob itself — a long take is enough to get the
 * app jetsammed by iOS mid-save. Filesystem decodes each call's payload
 * independently and appends the resulting bytes, so writing in slices is
 * byte-for-byte identical to one large write with bounded peak memory.
 */
const WRITE_SLICE_BYTES = 3 * 1024 * 1024

/** Write a blob to the takes directory without ever holding it all as base64. */
async function writeBlobToDataFile(blob: Blob, filePath: string): Promise<void> {
  if (blob.size <= WRITE_SLICE_BYTES) {
    await Filesystem.writeFile({
      path: filePath,
      data: await blobToBase64(blob),
      directory: Directory.Data,
    })
    return
  }

  for (let offset = 0; offset < blob.size; offset += WRITE_SLICE_BYTES) {
    const slice = blob.slice(offset, Math.min(offset + WRITE_SLICE_BYTES, blob.size))
    const base64 = await blobToBase64(slice)

    if (offset === 0) {
      await Filesystem.writeFile({
        path: filePath,
        data: base64,
        directory: Directory.Data,
      })
    } else {
      await Filesystem.appendFile({
        path: filePath,
        data: base64,
        directory: Directory.Data,
      })
    }
  }
}

function blobToBase64(blob: Blob): Promise<string> {
  return new Promise((resolve, reject) => {
    const reader = new FileReader()
    reader.onloadend = () => {
      const result = reader.result
      if (typeof result !== 'string') {
        reject(new Error('Failed to encode recording chunk'))
        return
      }
      const comma = result.indexOf(',')
      resolve(comma >= 0 ? result.slice(comma + 1) : result)
    }
    reader.onerror = () => reject(reader.error ?? new Error('Failed to read chunk'))
    reader.readAsDataURL(blob)
  })
}

/**
 * Streams MediaRecorder output to disk on native.
 * iOS/mp4: single blob on stop (fragment concat breaks A/V sync on long takes).
 * Android webm: append chunks incrementally.
 */
export class StreamingTakeWriter {
  readonly takeId: string
  readonly filePath: string
  readonly mimeType: string

  private writeChain = Promise.resolve()
  private chunkCount = 0
  private closed = false
  private aborted = false
  private fileMaterialized = false
  /**
   * First error from any chunk append. A dropped interior chunk leaves a hole
   * in the container, so the file is unplayable even though later chunks land —
   * `finalize()` must refuse it rather than present a corrupt take as good.
   */
  private writeError: unknown = null
  private readonly bufferChunks: Blob[] = []
  private readonly useBufferedWrite: boolean

  private constructor(
    takeId: string,
    filePath: string,
    mimeType: string,
    useBufferedWrite: boolean,
  ) {
    this.takeId = takeId
    this.filePath = filePath
    this.mimeType = mimeType
    this.useBufferedWrite = useBufferedWrite
  }

  static async open(
    takeId: string,
    mimeType: string,
  ): Promise<StreamingTakeWriter | null> {
    if (!Capacitor.isNativePlatform()) {
      return null
    }

    await ensureTakesDirectory()

    const ext = extensionForMime(mimeType)
    const filePath = `${TAKES_DIR}/${takeId}.${ext}`

    if (await nativeDataFileExists(filePath)) {
      await deleteTakeFile(filePath)
    }

    const useBufferedWrite =
      mimeType.includes('mp4') || Capacitor.getPlatform() === 'ios'

    return new StreamingTakeWriter(takeId, filePath, mimeType, useBufferedWrite)
  }

  /** Queue a recorder chunk; on iOS/mp4 they are buffered until finalize. */
  enqueue(chunk: Blob): Promise<void> {
    if (this.closed || this.aborted || chunk.size === 0) {
      return Promise.resolve()
    }

    if (this.useBufferedWrite) {
      this.bufferChunks.push(chunk)
      this.chunkCount += 1
      return Promise.resolve()
    }

    const task = this.writeChain.then(() => this.writeChunk(chunk))
    this.writeChain = task.catch((error: unknown) => {
      // Keep the chain alive so later chunks still drain, but remember that
      // this take now has a gap in it.
      if (this.writeError === null) {
        this.writeError = error
        console.error('[TakeStorage] chunk append failed — take is incomplete', error)
      }
    })
    return task
  }

  private async writeChunk(chunk: Blob): Promise<void> {
    if (this.aborted) return

    const base64 = await blobToBase64(chunk)

    if (this.chunkCount === 0) {
      await Filesystem.writeFile({
        path: this.filePath,
        data: base64,
        directory: Directory.Data,
      })
    } else {
      await Filesystem.appendFile({
        path: this.filePath,
        data: base64,
        directory: Directory.Data,
      })
    }

    this.chunkCount += 1
    this.fileMaterialized = true
  }

  async finalize(): Promise<PersistedTakeVideo> {
    if (this.aborted) {
      throw new Error('Recording was aborted')
    }

    this.closed = true
    await this.writeChain

    if (this.writeError !== null) {
      const cause = this.writeError
      reportError(cause, {
        phase: 'takeStorage.finalize',
        reason: 'chunkAppendFailed',
        takeId: this.takeId,
        chunksWritten: this.chunkCount,
      })
      await deleteTakeFile(this.filePath)
      throw new Error(
        `Recording is incomplete — a chunk failed to write: ${String(cause)}`,
      )
    }

    if (this.chunkCount === 0) {
      await deleteTakeFile(this.filePath)
      throw new Error('Recording contained no data')
    }

    if (this.useBufferedWrite) {
      const blob = composeBufferedRecordingBlob(this.bufferChunks, this.mimeType)
      this.bufferChunks.length = 0

      if (blob.size === 0) {
        await deleteTakeFile(this.filePath)
        throw new Error('Recording contained no data')
      }

      await writeBlobToDataFile(blob, this.filePath)

      const { uri } = await Filesystem.getUri({
        path: this.filePath,
        directory: Directory.Data,
      })

      return {
        filePath: this.filePath,
        videoUrl: rememberPlaybackSrc(
          this.filePath,
          Capacitor.convertFileSrc(uri),
        ),
      }
    }

    const { uri } = await Filesystem.getUri({
      path: this.filePath,
      directory: Directory.Data,
    })

    return {
      filePath: this.filePath,
      videoUrl: rememberPlaybackSrc(this.filePath, Capacitor.convertFileSrc(uri)),
    }
  }

  /** Discard a partial take and remove any bytes already written. */
  async abort(): Promise<void> {
    if (this.aborted) return

    this.aborted = true
    this.closed = true
    this.bufferChunks.length = 0
    await this.writeChain.catch(() => {})

    if (this.fileMaterialized || this.chunkCount > 0) {
      await deleteTakeFile(this.filePath)
    }
  }
}

/** Web-only: expose a blob URL after recording stops. */
export async function persistRecordingBlob(
  blob: Blob,
  _takeId: string,
  mimeType: string,
): Promise<PersistedTakeVideo> {
  const writeMime = normalizeBlobMime(mimeType)
  const normalized =
    blob.type === writeMime ? blob : new Blob([blob], { type: writeMime })

  return {
    filePath: '',
    videoUrl: URL.createObjectURL(normalized),
  }
}

/** Save a user-picked video to disk (native) or blob URL (web). */
export async function persistUploadedVideo(
  blob: Blob,
  takeId: string,
  mimeType: string,
): Promise<PersistedTakeVideo> {
  const writeMime = normalizeBlobMime(mimeType)
  const normalized =
    blob.type === writeMime ? blob : new Blob([blob], { type: writeMime })

  if (!Capacitor.isNativePlatform()) {
    return {
      filePath: '',
      videoUrl: URL.createObjectURL(normalized),
    }
  }

  await ensureTakesDirectory()

  const ext = extensionForMime(mimeType)
  const filePath = `${TAKES_DIR}/${takeId}.${ext}`

  await deleteTakeFile(filePath)

  await writeBlobToDataFile(normalized, filePath)

  const { uri } = await Filesystem.getUri({
    path: filePath,
    directory: Directory.Data,
  })

  return {
    filePath,
    videoUrl: Capacitor.convertFileSrc(uri),
  }
}

/**
 * Promote a native renderer's temporary movie into durable Take Vault storage.
 * Filesystem.copy keeps the MP4 byte-for-byte and avoids loading a full export
 * into WebKit memory as base64.
 */
export async function persistRenderedTakeVideo(
  renderedUri: string,
  takeId: string,
): Promise<PersistedTakeVideo> {
  if (!Capacitor.isNativePlatform() || !renderedUri) {
    throw new Error('Rendered Take Vault saves require a native file.')
  }

  await ensureTakesDirectory()
  const filePath = `${TAKES_DIR}/${takeId}.mp4`
  await deleteTakeFile(filePath)

  const copied = await Filesystem.copy({
    from: renderedUri,
    to: filePath,
    toDirectory: Directory.Data,
  })
  const uri = copied.uri || (
    await Filesystem.getUri({ path: filePath, directory: Directory.Data })
  ).uri

  return {
    filePath,
    videoUrl: rememberPlaybackSrc(filePath, Capacitor.convertFileSrc(uri)),
  }
}

export async function resolveTakePlaybackUrl(
  filePath: string,
  fallbackUrl: string,
): Promise<string> {
  if (!Capacitor.isNativePlatform()) {
    return fallbackUrl
  }

  const resolved = await resolveNativeVideoPlaybackSrc(filePath, fallbackUrl)
  if (resolved) return resolved

  return applyStrictPlaybackSrc(fallbackUrl)
}

const deleteTakeFileInFlight = new Map<string, Promise<boolean>>()

export async function deleteTakeFile(filePath: string): Promise<boolean> {
  if (!filePath || !Capacitor.isNativePlatform()) return true

  const inFlight = deleteTakeFileInFlight.get(filePath)
  if (inFlight) {
    return inFlight
  }

  const task = (async () => {
    try {
      const exists = await nativeDataFileExists(filePath)
      if (exists) {
        await Filesystem.deleteFile({
          path: filePath,
          directory: Directory.Data,
        })
      }
      return true
    } catch (err) {
      if (isFilesystemMissingError(err)) {
        return true
      }
      console.error('[TakeStorage] Failed to delete take file', { filePath, error: err })
      return false
    } finally {
      invalidatePlaybackSrcCache(filePath)
      deleteTakeFileInFlight.delete(filePath)
    }
  })()

  deleteTakeFileInFlight.set(filePath, task)
  return task
}
