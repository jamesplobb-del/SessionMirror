export const YOUTUBE_PROXY_ORIGIN = 'https://stalwart-salamander-9451ab.netlify.app'

const LEGACY_PROXY_HOSTS = new Set([
  'singular-manatee-b52df8.netlify.app',
  'stalwart-salamander-9451ab.netlify.app',
])

/** Build the Capacitor-safe proxy iframe URL for a YouTube video ID. */
export function buildYoutubeProxyUrl(videoId: string): string {
  const params = new URLSearchParams({
    v: videoId,
    controls: '1',
    modestbranding: '1',
    rel: '0',
    playsinline: '1',
    fs: '1',
  })
  return `${YOUTUBE_PROXY_ORIGIN}/?${params.toString()}`
}

/** Extract a YouTube video ID from a pasted URL or raw ID. */
export function parseYoutubeVideoId(input: string): string | null {
  const trimmed = input.trim()
  if (!trimmed) return null

  if (/^[\w-]{11}$/.test(trimmed)) {
    return trimmed
  }

  try {
    const url = new URL(trimmed.startsWith('http') ? trimmed : `https://${trimmed}`)
    const host = url.hostname.replace(/^www\./, '')
    const path = url.pathname.replace(/\/+$/, '')

    if (LEGACY_PROXY_HOSTS.has(host) || path === '/youtube-proxy' || path.endsWith('/youtube-proxy')) {
      const fromQuery = url.searchParams.get('v')
      return fromQuery && /^[\w-]{11}$/.test(fromQuery) ? fromQuery : null
    }

    if (host === 'youtu.be') {
      const id = url.pathname.slice(1).split('/')[0]
      return id && /^[\w-]{11}$/.test(id) ? id : null
    }

    if (host === 'youtube.com' || host.endsWith('.youtube.com') || host === 'youtube-nocookie.com' || host.endsWith('.youtube-nocookie.com')) {
      const fromQuery = url.searchParams.get('v')
      if (fromQuery && /^[\w-]{11}$/.test(fromQuery)) return fromQuery

      const parts = url.pathname.split('/').filter(Boolean)
      const embedIdx = parts.indexOf('embed')
      if (embedIdx >= 0 && parts[embedIdx + 1]) {
        const id = parts[embedIdx + 1]
        return /^[\w-]{11}$/.test(id) ? id : null
      }

      const shortsIdx = parts.indexOf('shorts')
      if (shortsIdx >= 0 && parts[shortsIdx + 1]) {
        const id = parts[shortsIdx + 1]
        return /^[\w-]{11}$/.test(id) ? id : null
      }
    }
  } catch {
    return null
  }

  return null
}

/** Parse a pasted YouTube URL or video ID into the proxy iframe URL. */
export function parseYoutubeEmbedUrl(input: string): string | null {
  const videoId = parseYoutubeVideoId(input)
  return videoId ? buildYoutubeProxyUrl(videoId) : null
}

/** Best-effort clipboard read — works after user returns from YouTube with a copied link. */
export async function readYoutubeUrlFromClipboard(): Promise<string | null> {
  if (typeof navigator === 'undefined' || !navigator.clipboard?.readText) return null
  try {
    const text = (await navigator.clipboard.readText()).trim()
    if (!text) return null
    return parseYoutubeVideoId(text) ? text : null
  } catch {
    return null
  }
}

/** Rebuild older proxy URLs to the current Netlify player page. */
export function normalizeYoutubeEmbedUrl(embedUrl: string): string {
  if (
    embedUrl.includes('/youtube-proxy') ||
    embedUrl.includes('singular-manatee-b52df8.netlify.app')
  ) {
    const videoId = parseYoutubeVideoId(embedUrl)
    return videoId ? buildYoutubeProxyUrl(videoId) : embedUrl
  }
  return embedUrl
}
