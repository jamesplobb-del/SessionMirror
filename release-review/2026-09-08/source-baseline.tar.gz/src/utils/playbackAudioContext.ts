import { APP_FOREGROUND_RECOVERY_EVENT } from './appForeground'

let playbackContext: AudioContext | null = null
let playbackContextWatchAttached = false

/**
 * iOS WKWebView contexts can sit in a non-standard 'interrupted' state (e.g.
 * after a native AVCaptureSession reconfigures the audio session). Treat any
 * non-running, non-closed state as resumable — checking only 'suspended'
 * leaves the context wedged and rendering silence.
 */
function needsResume(ctx: AudioContext): boolean {
  return ctx.state !== 'running' && ctx.state !== 'closed'
}

function isRunning(ctx: AudioContext): boolean {
  return ctx.state === 'running'
}

function attachPlaybackContextWatch(ctx: AudioContext): void {
  if (playbackContextWatchAttached) return
  playbackContextWatchAttached = true

  ctx.addEventListener('statechange', () => {
    if (needsResume(ctx)) {
      void ctx.resume().catch(() => {})
    }
  })

  const resumeOnVisible = () => {
    if (document.visibilityState === 'visible') {
      void ctx.resume().catch(() => {})
    }
  }
  document.addEventListener('visibilitychange', resumeOnVisible)

  window.addEventListener(APP_FOREGROUND_RECOVERY_EVENT, () => {
    void ctx.resume().catch(() => {})
  })
}

function createPlaybackContext(): AudioContext {
  const WebkitAudioContext = (
    window as Window & { webkitAudioContext?: typeof AudioContext }
  ).webkitAudioContext
  const Ctor = window.AudioContext ?? WebkitAudioContext
  if (!Ctor) {
    throw new Error('Web Audio API is not available')
  }
  return new Ctor({ latencyHint: 'playback' })
}

export async function getPlaybackAudioContext(): Promise<AudioContext> {
  if (!playbackContext || playbackContext.state === 'closed') {
    playbackContext = createPlaybackContext()
    playbackContextWatchAttached = false
  }

  attachPlaybackContextWatch(playbackContext)

  if (needsResume(playbackContext)) {
    await playbackContext.resume().catch(() => {})
  }

  return playbackContext
}

export async function resumePlaybackAudioContext(): Promise<void> {
  await getPlaybackAudioContext()
}

/**
 * Grouped playback cannot tolerate a context that merely accepted resume()
 * but remained suspended/interrupted. iOS occasionally needs a second resume
 * after the native AVAudioSession route has finished changing.
 */
export async function ensurePlaybackAudioContextRunning(): Promise<boolean> {
  const ctx = await getPlaybackAudioContext()
  if (isRunning(ctx)) return true

  await ctx.resume().catch(() => {})
  if (isRunning(ctx)) return true

  await new Promise<void>((resolve) => {
    window.requestAnimationFrame(() => resolve())
  })
  await ctx.resume().catch(() => {})
  return isRunning(ctx)
}

export function primePlaybackAudioContextSync(): AudioContext {
  if (!playbackContext || playbackContext.state === 'closed') {
    playbackContext = createPlaybackContext()
    playbackContextWatchAttached = false
  }

  attachPlaybackContextWatch(playbackContext)

  if (needsResume(playbackContext)) {
    void playbackContext.resume().catch((error: unknown) => {
      console.warn('Playback AudioContext resume blocked:', error)
    })
  }

  return playbackContext
}

export function isSharedPlaybackContext(context: AudioContext): boolean {
  return playbackContext === context
}
