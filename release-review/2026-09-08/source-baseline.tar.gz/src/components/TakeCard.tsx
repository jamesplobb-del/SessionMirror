import { memo, useEffect, useRef, useState, type KeyboardEvent, type MouseEvent } from 'react'
import {
  ChevronDown,
  Check,
  Clapperboard,
  Download,
  Mic2,
  Pin,
  Play,
  Sparkles,
  StickyNote,
  Target,
  Trash2,
  Trophy,
  Video,
} from 'lucide-react'
import StarRating from './StarRating'
import Pressable from './ui/Pressable'
import { useActionSheet } from '../context/ActionSheetContext'
import { triggerLightHaptic } from '../utils/haptics'
import { getTakeMediaType } from '../utils/mediaType'
import { reResolveCachedTakeThumbnail } from '../utils/takeThumbnailCache'
import type { Take, TakeUpdate } from '../types'
import type { BestTakeHistoryEntry } from '../db'
import TakeCardThumbnailSkeleton from './ui/TakeCardThumbnailSkeleton'

function TakeCardThumbnailPlaceholder() {
  return (
    <div className="vault-thumb-placeholder h-full w-full">
      <Clapperboard className="h-6 w-6 text-white/30" strokeWidth={1.5} aria-hidden />
    </div>
  )
}

interface TakeCardProps {
  take: Take
  takeIndex: number
  isBenchmark: boolean
  isChallenger: boolean
  /** Present when this take has held Best Take at some point in the project. */
  bestHistoryEntry?: BestTakeHistoryEntry | null
  detailOpen?: boolean
  onToggleDetail?: () => void
  onOpenTake?: () => void
  onPinBenchmark: () => void
  onPinChallenger: () => void
  onExport?: () => void
  onCreate?: () => void
  onUpdate: (updates: TakeUpdate) => void
  onDelete: () => void
  selectionMode?: boolean
  selected?: boolean
  onToggleSelect?: () => void
  exportBusy?: boolean
}

function TakeCard({
  take,
  takeIndex,
  isBenchmark,
  isChallenger,
  bestHistoryEntry = null,
  detailOpen = false,
  onToggleDetail,
  onOpenTake,
  onPinBenchmark,
  onPinChallenger,
  onExport,
  onCreate,
  onUpdate,
  onDelete,
  selectionMode = false,
  selected = false,
  onToggleSelect,
  exportBusy = false,
}: TakeCardProps) {
  const { showConfirm } = useActionSheet()
  const [isEditingName, setIsEditingName] = useState(false)
  const [nameDraft, setNameDraft] = useState(take.name)
  const [notesDraft, setNotesDraft] = useState(take.notes)
  const [thumbnailBroken, setThumbnailBroken] = useState(false)
  const [thumbnailSrc, setThumbnailSrc] = useState(take.thumbnailUrl)
  const [thumbnailRevision, setThumbnailRevision] = useState(0)
  const [actionFeedback, setActionFeedback] = useState<'best' | 'load' | null>(null)
  const notesDebounceRef = useRef<number | null>(null)
  const actionFeedbackTimerRef = useRef<number | null>(null)
  const nameInputRef = useRef<HTMLInputElement>(null)

  useEffect(() => {
    setNameDraft(take.name)
  }, [take.name])

  useEffect(() => {
    setNotesDraft(take.notes)
  }, [take.notes])

  useEffect(() => {
    return () => {
      if (notesDebounceRef.current !== null) {
        window.clearTimeout(notesDebounceRef.current)
      }
      if (actionFeedbackTimerRef.current !== null) {
        window.clearTimeout(actionFeedbackTimerRef.current)
      }
    }
  }, [])

  useEffect(() => {
    setThumbnailSrc(take.thumbnailUrl)
    setThumbnailBroken(false)
    setThumbnailRevision(0)
  }, [take.id, take.thumbnailUrl])

  useEffect(() => {
    const refreshThumbnail = () => {
      if (document.visibilityState !== 'visible' || !take.thumbnailUrl) return
      setThumbnailRevision((revision) => revision + 1)
      void reResolveCachedTakeThumbnail(take.id, take.recordingOrientation ?? 'portrait').then(
        (refreshed) => {
          if (refreshed) {
            setThumbnailSrc(refreshed)
            setThumbnailBroken(false)
          }
        },
      )
    }

    document.addEventListener('visibilitychange', refreshThumbnail)
    return () => document.removeEventListener('visibilitychange', refreshThumbnail)
  }, [take.id, take.recordingOrientation, take.thumbnailUrl])

  const handleThumbnailError = () => {
    void reResolveCachedTakeThumbnail(take.id, take.recordingOrientation ?? 'portrait').then(
      (refreshed) => {
        if (refreshed && refreshed !== thumbnailSrc) {
          setThumbnailSrc(refreshed)
          setThumbnailRevision((revision) => revision + 1)
          setThumbnailBroken(false)
          return
        }
        setThumbnailBroken(true)
      },
    )
  }

  useEffect(() => {
    if (!isEditingName) return
    nameInputRef.current?.focus()
    nameInputRef.current?.select()
  }, [isEditingName])

  const commitName = () => {
    const trimmed = nameDraft.trim()
    if (trimmed && trimmed !== take.name) {
      onUpdate({ name: trimmed })
    } else {
      setNameDraft(take.name)
    }
    setIsEditingName(false)
  }

  const handleRowActivate = () => {
    if (selectionMode) {
      triggerLightHaptic()
      onToggleSelect?.()
      return
    }
    triggerLightHaptic()
    onToggleDetail?.()
  }

  const handlePrimaryOpen = () => {
    if (selectionMode) {
      triggerLightHaptic()
      onToggleSelect?.()
      return
    }
    triggerLightHaptic()
    onOpenTake?.()
  }

  const handleKeyActivate = (event: KeyboardEvent<HTMLElement>) => {
    if (event.key !== 'Enter' && event.key !== ' ') return
    event.preventDefault()
    handlePrimaryOpen()
  }

  const stopNestedClick = (event: MouseEvent<HTMLElement>) => {
    event.stopPropagation()
  }

  const handlePlay = (event?: MouseEvent<HTMLElement>) => {
    event?.stopPropagation()
    triggerLightHaptic()
    onOpenTake?.()
  }

  const flashActionFeedback = (action: 'best' | 'load') => {
    setActionFeedback(action)
    if (actionFeedbackTimerRef.current !== null) {
      window.clearTimeout(actionFeedbackTimerRef.current)
    }
    actionFeedbackTimerRef.current = window.setTimeout(() => {
      actionFeedbackTimerRef.current = null
      setActionFeedback((current) => (current === action ? null : current))
    }, 950)
  }

  const handleDelete = (event?: MouseEvent<HTMLElement>) => {
    event?.stopPropagation()
    void (async () => {
      const confirmed = await showConfirm({
        message: `Delete "${take.name}"? This cannot be undone.`,
        destructive: true,
        confirmLabel: 'Delete',
      })
      if (confirmed) onDelete()
    })()
  }

  const showThumbnailImage = Boolean(thumbnailSrc) && !thumbnailBroken
  const showThumbnailSkeleton = !thumbnailSrc && !thumbnailBroken
  const mediaType = getTakeMediaType(take)
  const MediaIcon = mediaType === 'audio' ? Mic2 : Video

  const rowClass = [
    'vault-take-row interactive-native group relative',
    isBenchmark ? 'vault-take-row--benchmark' : '',
    isChallenger ? 'vault-take-row--challenger' : '',
    selectionMode && selected ? 'vault-take-row--selected' : '',
    detailOpen ? 'vault-take-row--expanded' : '',
    actionFeedback ? 'vault-take-row--action-feedback' : '',
  ]
    .filter(Boolean)
    .join(' ')

  const formattedDate = new Date(take.timestamp).toLocaleString([], {
    month: 'short',
    day: 'numeric',
    hour: 'numeric',
    minute: '2-digit',
  })

  const focusArea = take.focusArea?.trim() ?? ''
  const bestMarkedDate = bestHistoryEntry
    ? new Date(bestHistoryEntry.markedAt).toLocaleDateString([], {
        month: 'short',
        day: 'numeric',
      })
    : ''

  return (
    <article className={rowClass} data-tutorial="vault-take-card">
      <div
        className="vault-take-row__main"
        role="button"
        tabIndex={0}
        aria-label={
          selectionMode
            ? `${selected ? 'Deselect' : 'Select'} ${take.name}`
            : `Open ${take.name} full screen`
        }
        onClick={handlePrimaryOpen}
        onKeyDown={handleKeyActivate}
      >
        <div
          className="vault-take-row__thumb cursor-pointer"
        >
          {showThumbnailImage ? (
            <img
              src={
                thumbnailRevision > 0
                  ? `${thumbnailSrc}${thumbnailSrc.includes('?') ? '&' : '?'}v=${thumbnailRevision}`
                  : thumbnailSrc
              }
              alt=""
              className="pointer-events-none h-full w-full object-cover"
              draggable={false}
              loading="lazy"
              decoding="async"
              onError={handleThumbnailError}
            />
          ) : showThumbnailSkeleton ? (
            <TakeCardThumbnailSkeleton />
          ) : (
            <TakeCardThumbnailPlaceholder />
          )}
          <span className="vault-take-row__take-tag">TAKE {takeIndex + 1}</span>
          {selectionMode && (
            <div
              className={`absolute right-1 top-1 flex h-5 w-5 items-center justify-center rounded-full border-2 ${
                selected
                  ? 'border-sky-400 bg-sky-500 text-white'
                  : 'border-white/80 bg-black/40 text-transparent'
              }`}
              aria-hidden
            >
              <Check className="h-3 w-3" strokeWidth={3} />
            </div>
          )}
        </div>

        <div className="vault-take-row__body">
          <div>
            <div className="vault-take-row__title-row">
              {isEditingName ? (
                <input
                  ref={nameInputRef}
                  type="text"
                  value={nameDraft}
                  onChange={(event) => setNameDraft(event.target.value)}
                  onBlur={commitName}
                  onClick={stopNestedClick}
                  onKeyDown={(event) => {
                    if (event.key === 'Enter') commitName()
                    if (event.key === 'Escape') {
                      setNameDraft(take.name)
                      setIsEditingName(false)
                    }
                  }}
                  className="vault-take-row__title-input"
                  aria-label="Rename take"
                />
              ) : (
                <Pressable
                  type="button"
                  intensity="soft"
                  haptic="light"
                  onClick={(event) => {
                    event.stopPropagation()
                    if (detailOpen) {
                      setIsEditingName(true)
                    } else {
                      handlePrimaryOpen()
                    }
                  }}
                  className="vault-take-row__title min-w-0 flex-1 truncate text-left"
                  title={detailOpen ? 'Click to rename' : 'Open full screen'}
                >
                  {take.name}
                </Pressable>
              )}
            </div>
            <p className="vault-take-row__date">{formattedDate}</p>
            {(bestHistoryEntry || focusArea) && (
              <div className="vault-take-row__practice-chips">
                {bestHistoryEntry && (
                  <span
                    className={`vault-take-row__best-chip ${
                      bestHistoryEntry.isCurrentBest
                        ? 'vault-take-row__best-chip--current'
                        : 'vault-take-row__best-chip--past'
                    }`}
                  >
                    <Trophy className="h-3 w-3" aria-hidden />
                    {bestHistoryEntry.isCurrentBest
                      ? 'Current best'
                      : `Previous best · ${bestMarkedDate}`}
                  </span>
                )}
                {focusArea && (
                  <span className="vault-take-row__focus-chip truncate">
                    <Target className="h-3 w-3 shrink-0" aria-hidden />
                    <span className="truncate">{focusArea}</span>
                  </span>
                )}
              </div>
            )}
            {take.rating > 0 && !detailOpen && (
              <p className="vault-take-row__rating-hint" aria-hidden>
                {'★'.repeat(take.rating)}
                {'☆'.repeat(5 - take.rating)}
              </p>
            )}
            {take.notes.trim() && !detailOpen && (
              <p className="vault-take-row__notes-hint truncate">{take.notes}</p>
            )}
            {take.intention?.trim() && !detailOpen && !take.notes.trim() && (
              <p className="vault-take-row__notes-hint truncate">
                Next-take cue: {take.intention}
              </p>
            )}
          </div>

          <div className="vault-take-row__footer">
            <span className="vault-take-row__type">
              <MediaIcon className="h-3 w-3" aria-hidden />
              {mediaType}
            </span>
            <div className="vault-take-row__actions">
              {!selectionMode && onToggleDetail && (
                <Pressable
                  type="button"
                  intensity="icon"
                  haptic="light"
                  className={`vault-take-row__icon-btn vault-take-row__dropdown-btn ${
                    detailOpen ? 'vault-take-row__dropdown-btn--open' : ''
                  }`}
                  aria-label={`${detailOpen ? 'Hide' : 'Show'} take actions`}
                  aria-expanded={detailOpen}
                  onClick={(event) => {
                    event.stopPropagation()
                    handleRowActivate()
                  }}
                >
                  <ChevronDown className="h-4 w-4" />
                </Pressable>
              )}
              {!selectionMode && onOpenTake && (
                <Pressable
                  type="button"
                  intensity="icon"
                  haptic="medium"
                  className="vault-take-row__play-btn"
                  aria-label={`Play ${take.name}`}
                  onClick={handlePlay}
                >
                  <Play className="h-4 w-4 fill-current" />
                </Pressable>
              )}
            </div>
          </div>
        </div>
      </div>

      {detailOpen && !selectionMode && (
        <div className="vault-take-row__detail">
          {focusArea && (
            <div className="vault-take-row__detail-section vault-take-row__focus">
              <p className="vault-take-row__detail-label">
                <Target className="h-3.5 w-3.5" aria-hidden />
                Practicing
              </p>
              <p>{focusArea}</p>
            </div>
          )}
          {take.intention?.trim() && (
            <div className="vault-take-row__detail-section vault-take-row__intention">
              <p className="vault-take-row__detail-label">
                <Sparkles className="h-3.5 w-3.5" aria-hidden />
                Cue before this take
              </p>
              <p>{take.intention}</p>
            </div>
          )}
          <div className="vault-take-row__detail-section" onClick={stopNestedClick}>
            <p className="vault-take-row__detail-label">Rating</p>
            <StarRating rating={take.rating} onChange={(rating) => onUpdate({ rating })} />
          </div>

          <div className="vault-take-row__detail-section" onClick={stopNestedClick}>
            <label className="vault-take-row__detail-label" htmlFor={`take-notes-${take.id}`}>
              <StickyNote className="h-3.5 w-3.5" aria-hidden />
              Notes
            </label>
            <textarea
              id={`take-notes-${take.id}`}
              value={notesDraft}
              onChange={(event) => {
                const value = event.target.value
                setNotesDraft(value)
                if (notesDebounceRef.current !== null) {
                  window.clearTimeout(notesDebounceRef.current)
                }
                notesDebounceRef.current = window.setTimeout(() => {
                  notesDebounceRef.current = null
                  onUpdate({ notes: value })
                }, 400)
              }}
              rows={3}
              placeholder="Chord changes, feel, what to fix next time…"
              className="vault-take-row__notes-input"
            />
          </div>

          <div className="vault-take-row__detail-actions">
            {onOpenTake && (
              <button type="button" className="vault-take-row__detail-btn" onClick={handlePlay}>
                <Play className="h-3.5 w-3.5" />
                Play
              </button>
            )}
            <button
              type="button"
              className={`vault-take-row__detail-btn ${
                actionFeedback === 'best' ? 'vault-take-row__detail-btn--confirmed' : ''
              }`}
              data-tutorial="vault-pin-best"
              onClick={(event) => {
                event.stopPropagation()
                flashActionFeedback('best')
                onPinBenchmark()
              }}
            >
              {actionFeedback === 'best' ? (
                <Check className="h-3.5 w-3.5" />
              ) : (
                <Pin className="h-3.5 w-3.5" />
              )}
              {actionFeedback === 'best' ? 'Made Best' : isBenchmark ? 'Best Take' : 'Make Best'}
            </button>
            <button
              type="button"
              className={`vault-take-row__detail-btn ${
                actionFeedback === 'load' ? 'vault-take-row__detail-btn--confirmed' : ''
              }`}
              onClick={(event) => {
                event.stopPropagation()
                flashActionFeedback('load')
                onPinChallenger()
              }}
            >
              {actionFeedback === 'load' ? (
                <Check className="h-3.5 w-3.5" />
              ) : (
                <Pin className="h-3.5 w-3.5" />
              )}
              {actionFeedback === 'load' ? 'Loaded' : 'Load Take'}
            </button>
            {onCreate && mediaType === 'video' && (
              <button
                type="button"
                className="vault-take-row__detail-btn"
                data-tutorial="vault-expand"
                onClick={(event) => {
                  event.stopPropagation()
                  onCreate()
                }}
              >
                <Sparkles className="h-3.5 w-3.5" />
                Create
              </button>
            )}
            {onExport && (
              <button
                type="button"
                className="vault-take-row__detail-btn"
                disabled={exportBusy}
                onClick={(event) => {
                  event.stopPropagation()
                  onExport()
                }}
              >
                <Download className="h-3.5 w-3.5" />
                {exportBusy ? 'Saving…' : 'Save Video'}
              </button>
            )}
            <button
              type="button"
              className="vault-take-row__detail-btn vault-take-row__detail-btn--danger"
              onClick={handleDelete}
            >
              <Trash2 className="h-3.5 w-3.5" />
              Delete
            </button>
          </div>
        </div>
      )}
    </article>
  )
}

export default memo(TakeCard, (previous, next) =>
  previous.take.id === next.take.id &&
  previous.takeIndex === next.takeIndex &&
  previous.take.thumbnailUrl === next.take.thumbnailUrl &&
  previous.take.name === next.take.name &&
  previous.take.notes === next.take.notes &&
  previous.take.intention === next.take.intention &&
  previous.take.focusArea === next.take.focusArea &&
  previous.bestHistoryEntry?.id === next.bestHistoryEntry?.id &&
  previous.bestHistoryEntry?.isCurrentBest === next.bestHistoryEntry?.isCurrentBest &&
  previous.take.rating === next.take.rating &&
  previous.take.mediaType === next.take.mediaType &&
  previous.isBenchmark === next.isBenchmark &&
  previous.isChallenger === next.isChallenger &&
  previous.detailOpen === next.detailOpen &&
  previous.selectionMode === next.selectionMode &&
  previous.selected === next.selected &&
  previous.onCreate === next.onCreate &&
  previous.exportBusy === next.exportBusy,
)
